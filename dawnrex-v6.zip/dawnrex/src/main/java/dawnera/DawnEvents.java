package dawnera;

import dawnera.entity.EntityDawnCreature;
import net.minecraft.entity.Entity;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class DawnEvents {
    /** A rider hitting any entity makes the mount play its own attack instead. */
    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        Entity mount = e.getEntityPlayer().getRidingEntity();
        if (mount instanceof EntityDawnCreature) {
            if (!e.getEntityPlayer().world.isRemote) ((EntityDawnCreature) mount).riderAttack();
            e.setCanceled(true);
        }
    }
}
