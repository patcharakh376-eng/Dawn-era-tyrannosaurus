package dawnera.entity;

import dawnera.DawnEra;
import dawnera.DawnItems;
import dawnera.DawnSounds;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.init.MobEffects;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Shared core for every Dawn Era creature on 1.12.2: growth, gender, hunger, sleep, taming by feeding,
 * saddle + armor, riding, and a small action state machine (replacement for AstemirLib ActionState).
 */
public abstract class EntityDawnCreature extends EntityTameable {
    /** One playable action (attack, roar, ...). length is in ticks. */
    public static class Action {
        public final String id, anim;
        public final int length;
        public Action(String id, String anim, int length) { this.id = id; this.anim = anim; this.length = length; }
    }

    private static final DataParameter<Integer> ACTION = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> SADDLED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> ARMORED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> MALE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> SLEEPING = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> AGE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> FOLLOW = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Float> HUNGER = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.FLOAT);
    private static final UUID ARMOR_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a12");

    /** Extra armor points while wearing the armor item. */
    protected static final double ARMOR_BONUS = 15.0D;
    /** Multiplier for all attack damage (Dawn Era values are very high). */
    protected static final float DAMAGE_SCALE = 1.0F;

    public int actionTick;
    private int growCounter;
    private float lastScale = -1F;

    // client-side animation state (plain data, read only by the renderer)
    public String animCur = "";
    public String animPrev = "";
    public float animCurTime, animPrevTime, animChangeAt;
    private boolean wasSleeping;
    public int sleepTransTick = 1000;
    public boolean sleepTransWake;

    protected EntityDawnCreature(World world) {
        super(world);
        this.stepHeight = 2.0F;
    }

    // ------------------------------------------------------------ species data (implemented by each creature)

    public abstract String getSpeciesId();
    protected abstract Action[] getActions();
    protected abstract float getBaseWidth();
    protected abstract float getBaseHeight();
    /** Ticks until fully grown. */
    protected abstract int getAdultAgeTicks();
    protected abstract float getMaxHunger();
    public abstract Action pickAttack();
    /** Server-side: called once per tick while an action plays. t = ticks since the action started. */
    protected abstract void onActionTick(Action a, int t);
    @Nullable protected Action getEatAction() { return null; }

    // ------------------------------------------------------------ data

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(ACTION, 0);
        dataManager.register(SADDLED, false);
        dataManager.register(ARMORED, false);
        dataManager.register(MALE, true);
        dataManager.register(SLEEPING, false);
        dataManager.register(AGE, Integer.MAX_VALUE / 2);
        dataManager.register(HUNGER, 100F);
        dataManager.register(FOLLOW, true);
    }

    /** Call at the end of each species constructor. */
    protected void initDefaults() {
        setSize(getBaseWidth(), getBaseHeight());
        dataManager.set(MALE, rand.nextBoolean());
        dataManager.set(HUNGER, getMaxHunger());
        setHealth(getMaxHealth());
    }

    public boolean isMale() { return dataManager.get(MALE); }
    public int getAge() { return dataManager.get(AGE); }
    public void setAge(int ticks) { dataManager.set(AGE, ticks); }
    public boolean isAdult() { return getAge() >= getAdultAgeTicks(); }
    @Override public boolean isChild() { return !isAdult(); }
    public float getGrowthProgress() { return Math.min(1.0F, getAge() / (float) getAdultAgeTicks()); }
    public float getHunger() { return dataManager.get(HUNGER); }
    public float getMaxHungerPublic() { return getMaxHunger(); }
    public boolean isHungry() { return getHunger() < getMaxHunger() * 0.6F; }
    public boolean isDawnSleeping() { return dataManager.get(SLEEPING); }
    public void setDawnSleeping(boolean v) { dataManager.set(SLEEPING, v); }
    public boolean isFollowing() { return dataManager.get(FOLLOW); }
    public void setFollowing(boolean v) { dataManager.set(FOLLOW, v); }
    public void toggleSit() { aiSit.setSitting(!isSitting()); isJumping = false; navigator.clearPath(); setAttackTarget(null); }
    public boolean isSaddled() { return dataManager.get(SADDLED); }
    public boolean isArmored() { return dataManager.get(ARMORED); }
    public void setSaddled(boolean v) { dataManager.set(SADDLED, v); }

    public void setArmored(boolean v) {
        dataManager.set(ARMORED, v);
        if (world.isRemote) return;
        IAttributeInstance attr = getEntityAttribute(SharedMonsterAttributes.ARMOR);
        if (attr.getModifier(ARMOR_UUID) != null) attr.removeModifier(ARMOR_UUID);
        if (v) attr.applyModifier(new AttributeModifier(ARMOR_UUID, "dawnera armor", ARMOR_BONUS, 0));
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setInteger("DawnAge", getAge());
        c.setFloat("DawnHunger", getHunger());
        c.setBoolean("DawnMale", isMale());
        c.setBoolean("DawnSaddled", isSaddled());
        c.setBoolean("DawnArmored", isArmored());
        c.setBoolean("DawnFollow", isFollowing());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        if (c.hasKey("DawnAge")) setAge(c.getInteger("DawnAge"));
        if (c.hasKey("DawnHunger")) dataManager.set(HUNGER, c.getFloat("DawnHunger"));
        if (c.hasKey("DawnMale")) dataManager.set(MALE, c.getBoolean("DawnMale"));
        setSaddled(c.getBoolean("DawnSaddled"));
        setArmored(c.getBoolean("DawnArmored"));
        if (c.hasKey("DawnFollow")) setFollowing(c.getBoolean("DawnFollow"));
    }

    // ------------------------------------------------------------ actions

    public Action getAction() {
        int i = dataManager.get(ACTION);
        Action[] all = getActions();
        return i > 0 && i <= all.length ? all[i - 1] : null;
    }

    public boolean isLocked() { return getAction() != null; }

    public void startAction(Action a) { startAction(a, false); }

    public void startAction(Action a, boolean force) {
        if (world.isRemote || a == null) return;
        if (!force && getAction() != null) return;
        Action[] all = getActions();
        for (int i = 0; i < all.length; i++) {
            if (all[i] == a) {
                dataManager.set(ACTION, i + 1);
                actionTick = 0;
                return;
            }
        }
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        super.notifyDataManagerChange(key);
        if (ACTION.equals(key)) actionTick = 0;
    }

    public void riderAttack() {
        if (!isDawnSleeping() && getAction() == null && isAdult()) startAction(pickAttack());
    }

    // ------------------------------------------------------------ tick

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        float s = 0.3F + 0.7F * getGrowthProgress();
        if (Math.abs(s - lastScale) > 0.01F) {
            lastScale = s;
            setSize(getBaseWidth() * s, getBaseHeight() * s);
        }

        Action a = getAction();
        if (a != null) {
            if (actionTick < a.length) actionTick++;
            if (!world.isRemote) {
                onActionTick(a, actionTick);
                if (actionTick >= a.length) {
                    dataManager.set(ACTION, 0);
                    actionTick = 0;
                }
            }
        }

        if (!world.isRemote) {
            if (ticksExisted % 20 == 0) {
                int age = getAge();
                if (age < getAdultAgeTicks()) setAge(Math.min(getAdultAgeTicks(), age + 20));
                dataManager.set(HUNGER, Math.max(0F, getHunger() - 0.25F));
            }
            updateSleep();
        } else {
            if (isDawnSleeping() != wasSleeping) {
                wasSleeping = isDawnSleeping();
                sleepTransWake = !wasSleeping;
                sleepTransTick = 0;
            }
            if (sleepTransTick < 1000) sleepTransTick++;
        }
    }

    private void updateSleep() {
        long t = world.getWorldTime() % 24000L;
        boolean night = t >= 13500L && t < 23000L;
        boolean calm = getAttackTarget() == null && onGround && !isInWater() && !isBeingRidden() && getAction() == null;
        if (!isDawnSleeping()) {
            if (night && calm && !isSitting() && rand.nextInt(300) == 0) setDawnSleeping(true);
        } else if (!night || !calm) {
            setDawnSleeping(false);
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (isDawnSleeping() && !world.isRemote) setDawnSleeping(false);
        return super.attackEntityFrom(src, amount);
    }

    @Override
    protected boolean isMovementBlocked() {
        return super.isMovementBlocked() || isDawnSleeping() || isLocked();
    }

    @Override
    public boolean canBePushed() { return false; }

    // ------------------------------------------------------------ riding

    @Override
    @Nullable
    public Entity getControllingPassenger() {
        List<Entity> l = getPassengers();
        return l.isEmpty() ? null : l.get(0);
    }

    @Override
    public double getMountedYOffset() { return height * 0.85D; }

    @Override
    public void travel(float strafe, float vertical, float forward) {
        Entity rider = getControllingPassenger();
        if (isBeingRidden() && rider instanceof EntityLivingBase && isSaddled()) {
            EntityLivingBase r = (EntityLivingBase) rider;
            rotationYaw = r.rotationYaw;
            prevRotationYaw = rotationYaw;
            rotationPitch = r.rotationPitch * 0.5F;
            setRotation(rotationYaw, rotationPitch);
            renderYawOffset = rotationYaw;
            rotationYawHead = renderYawOffset;
            strafe = r.moveStrafing * 0.5F;
            forward = r.moveForward;
            if (forward <= 0.0F) forward *= 0.25F;
            if (isLocked() || isDawnSleeping()) { strafe = 0F; forward = 0F; }
            if (canPassengerSteer()) {
                float speed = (float) getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue();
                setAIMoveSpeed(speed * (r.isSprinting() ? 1.8F : 0.9F));
                super.travel(strafe, vertical, forward);
            } else {
                motionX = 0.0D; motionY = 0.0D; motionZ = 0.0D;
            }
            prevLimbSwingAmount = limbSwingAmount;
            double dx = posX - prevPosX, dz = posZ - prevPosZ;
            float f = MathHelper.sqrt(dx * dx + dz * dz) * 4.0F;
            if (f > 1.0F) f = 1.0F;
            limbSwingAmount += (f - limbSwingAmount) * 0.4F;
            limbSwing += limbSwingAmount;
            return;
        }
        if (isLocked() || isDawnSleeping()) { strafe = 0.0F; forward = 0.0F; }
        super.travel(strafe, vertical, forward);
        if (isLocked() || isDawnSleeping()) { motionX = 0.0D; motionZ = 0.0D; }
    }

    // ------------------------------------------------------------ interaction

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack s = player.getHeldItem(hand);

        if (s.getItem() instanceof ItemFood && ((ItemFood) s.getItem()).isWolfsFavoriteMeat()) {
            if (getHunger() < getMaxHunger() - 1F) {
                if (!world.isRemote) {
                    dataManager.set(HUNGER, Math.min(getMaxHunger(), getHunger() + ((ItemFood) s.getItem()).getHealAmount(s) * 4F));
                    if (!player.capabilities.isCreativeMode) s.shrink(1);
                    playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0F, 0.7F);
                    if (getEatAction() != null) startAction(getEatAction());
                    if (!isTamed() && isAdult()) {          // Dawn Era TameMethod: feed, chance 1
                        setTamedBy(player);
                        navigator.clearPath();
                        setAttackTarget(null);
                        world.setEntityState(this, (byte) 7);
                    }
                }
                return true;
            }
            return false;
        }

        if (isTamed() && isOwner(player) && isAdult()) {
            if (s.getItem() == DawnItems.SADDLE && !isSaddled()) {
                if (!world.isRemote) {
                    setSaddled(true);
                    playSound(SoundEvents.ENTITY_HORSE_SADDLE, 0.5F, 1.0F);
                    if (!player.capabilities.isCreativeMode) s.shrink(1);
                }
                return true;
            }
            if (s.getItem() == DawnItems.ARMOR && !isArmored()) {
                if (!world.isRemote) {
                    setArmored(true);
                    playSound(SoundEvents.ENTITY_HORSE_ARMOR, 0.5F, 1.0F);
                    if (!player.capabilities.isCreativeMode) s.shrink(1);
                }
                return true;
            }
            if (s.isEmpty() && hand == EnumHand.MAIN_HAND) {
                if (player.isSneaking()) {
                    if (!world.isRemote) player.openGui(DawnEra.INSTANCE, 0, world, getEntityId(), 0, 0);
                    return true;
                }
                if (isSaddled() && !isBeingRidden()) {
                    if (!world.isRemote) player.startRiding(this);
                    return true;
                }
            }
        }
        return false;
    }

    // ------------------------------------------------------------ combat helpers

    protected boolean isFriendly(Entity e, @Nullable EntityPlayer rider) {
        if (e == this || e.getClass() == this.getClass() || isPassenger(e) || e == rider) return true;
        if (e instanceof EntityTameable) {
            EntityTameable pet = (EntityTameable) e;
            if (rider != null && pet.isOwner(rider)) return true;
            if (getOwner() != null && pet.isOwner(getOwner())) return true;
        }
        return e instanceof EntityPlayer && isTamed() && isOwner((EntityPlayer) e);
    }

    @Nullable
    protected EntityPlayer getRiderPlayer() {
        Entity r = getControllingPassenger();
        return r instanceof EntityPlayer ? (EntityPlayer) r : null;
    }

    protected void damage(EntityLivingBase t, float mult) {
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * mult * DAMAGE_SCALE;
        t.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
    }

    protected void slow(EntityLivingBase t, int ticks, int amp) {
        t.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, ticks, amp, true, false));
    }

    protected List<EntityLivingBase> frontEntities(double reach) {
        EntityPlayer rider = getRiderPlayer();
        float yaw = renderYawOffset * 0.017453292F;
        Vec3d fwd = new Vec3d(-MathHelper.sin(yaw), 0.0D, MathHelper.cos(yaw));
        List<EntityLivingBase> all = world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(reach, 1.5D, reach));
        all.removeIf(e -> {
            if (isFriendly(e, rider)) return true;
            double dx = e.posX - posX, dz = e.posZ - posZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            return len > 0.001D && (dx / len * fwd.x + dz / len * fwd.z) < 0.3D;
        });
        return all;
    }

    // ------------------------------------------------------------ sounds / drops

    @Nullable
    protected SoundEvent sound(String name) {
        return DawnSounds.get("entity." + getSpeciesId() + "." + name);
    }

    @Override protected SoundEvent getAmbientSound() {
        if (isLocked()) return null;
        return sound(isDawnSleeping() ? "sleep" : "idle");
    }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return sound("hurt"); }
    @Override protected SoundEvent getDeathSound() { return sound("death"); }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        int n = 2 + rand.nextInt(3 + looting);
        for (int i = 0; i < n; i++) dropItem(Items.BONE, 1);
        if (recentlyHit) for (int i = 0; i < 2 + rand.nextInt(3); i++) dropItem(Items.BEEF, 1);
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) {
            if (isSaddled()) entityDropItem(new ItemStack(DawnItems.SADDLE), 0.5F);
            if (isArmored()) entityDropItem(new ItemStack(DawnItems.ARMOR), 0.5F);
        }
        super.onDeath(cause);
    }

    /** Helper for AI/handlers to read how long the current action has played. */
    public float actionSeconds(float partial) { return (actionTick + partial) / 20F; }

    @Override
    public EntityTameable createChild(net.minecraft.entity.EntityAgeable other) { return null; }
}
