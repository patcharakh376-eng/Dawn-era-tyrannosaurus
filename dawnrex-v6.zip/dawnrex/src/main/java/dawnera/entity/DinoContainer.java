package dawnera.entity;

import dawnera.DawnItems;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Container;
import net.minecraft.inventory.InventoryBasic;
import net.minecraft.inventory.Slot;
import net.minecraft.item.ItemStack;

/** Saddle + armor slots of a tamed creature, plus the normal player inventory. Buttons: 0 = follow/wander, 1 = sit/stand. */
public class DinoContainer extends Container {
    public final EntityDawnCreature dino;
    private final InventoryBasic gear = new InventoryBasic("dino", false, 2);

    private class GearSlot extends Slot {
        private final boolean saddle;
        GearSlot(int index, int x, int y, boolean saddle) { super(gear, index, x, y); this.saddle = saddle; }
        @Override public boolean isItemValid(ItemStack s) { return s.getItem() == (saddle ? DawnItems.SADDLE : DawnItems.ARMOR); }
        @Override public int getSlotStackLimit() { return 1; }
        @Override public void onSlotChanged() {
            super.onSlotChanged();
            if (dino.world.isRemote) return;
            if (saddle) dino.setSaddled(getHasStack()); else dino.setArmored(getHasStack());
        }
    }

    public DinoContainer(InventoryPlayer inv, EntityDawnCreature dino) {
        this.dino = dino;
        if (dino.isSaddled()) gear.setInventorySlotContents(0, new ItemStack(DawnItems.SADDLE));
        if (dino.isArmored()) gear.setInventorySlotContents(1, new ItemStack(DawnItems.ARMOR));
        addSlotToContainer(new GearSlot(0, 98, 62, true));
        addSlotToContainer(new GearSlot(1, 120, 62, false));
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 124 + r * 18));
        for (int c = 0; c < 9; c++) addSlotToContainer(new Slot(inv, c, 8 + c * 18, 182));
    }

    @Override
    public boolean canInteractWith(EntityPlayer p) {
        return dino.isEntityAlive() && p.getDistanceSq(dino) < 64.0D && dino.isOwner(p);
    }

    @Override
    public boolean enchantItem(EntityPlayer p, int id) {
        if (dino.world.isRemote) return true;
        if (id == 0) {
            dino.setFollowing(!dino.isFollowing());
            return true;
        }
        if (id == 1) {
            dino.toggleSit();
            return true;
        }
        return false;
    }

    @Override
    public ItemStack transferStackInSlot(EntityPlayer p, int index) {
        ItemStack copy = ItemStack.EMPTY;
        Slot slot = inventorySlots.get(index);
        if (slot != null && slot.getHasStack()) {
            ItemStack st = slot.getStack();
            copy = st.copy();
            if (index < 2) {
                if (!mergeItemStack(st, 2, inventorySlots.size(), true)) return ItemStack.EMPTY;
            } else if (st.getItem() == DawnItems.SADDLE) {
                if (!mergeItemStack(st, 0, 1, false)) return ItemStack.EMPTY;
            } else if (st.getItem() == DawnItems.ARMOR) {
                if (!mergeItemStack(st, 1, 2, false)) return ItemStack.EMPTY;
            } else return ItemStack.EMPTY;
            if (st.isEmpty()) slot.putStack(ItemStack.EMPTY); else slot.onSlotChanged();
        }
        return copy;
    }
}
