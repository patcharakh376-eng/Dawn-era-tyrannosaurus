package dawnera.entity;

import dawnera.DawnSounds;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.block.Block;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;
import net.minecraft.util.math.Vec3d;

/** Tyrannosaurus (Dawn Era values: tyrannosaurus.json). */
public class EntityDawnTyrannosaurus extends EntityDawnCreature {
    public static final Action ATTACK1 = new Action("attack1", "animation.model.attack1", 15);
    public static final Action ATTACK2 = new Action("attack2", "animation.model.attack2", 19);
    public static final Action RAM = new Action("ram", "animation.model.attack3", 20);
    public static final Action GROUND = new Action("ground", "animation.model.attack4", 24);
    public static final Action ROAR = new Action("roar", "animation.model.roar", 81);
    public static final Action SNIFF = new Action("sniff", "animation.model.sniff", 39);
    public static final Action EAT = new Action("eat", "animation.model.eat", 66);
    private static final Action[] ACTIONS = {ATTACK1, ATTACK2, RAM, GROUND, ROAR, SNIFF, EAT};

    public EntityDawnTyrannosaurus(World world) {
        super(world);
        setSize(4.0F, 4.5F);
        experienceValue = 40;
        initDefaults();
    }

    @Override public String getSpeciesId() { return "tyrannosaurus"; }
    @Override protected Action[] getActions() { return ACTIONS; }
    @Override protected float getBaseWidth() { return 4.0F; }
    @Override protected float getBaseHeight() { return 4.5F; }
    @Override protected int getAdultAgeTicks() { return 24000 * 5; }
    @Override protected float getMaxHunger() { return 150.0F; }
    @Override protected Action getEatAction() { return EAT; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(370.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
        getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
        getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(60.0D);
        getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(35.0D);
    }

    @Override
    protected void initEntityAI() {
        this.aiSit = new EntityAISit(this);
        tasks.addTask(0, new EntityAISwimming(this));
        tasks.addTask(1, aiSit);
        tasks.addTask(2, new DawnAIMelee(this, 1.7D));
        tasks.addTask(3, new EntityAIFollowOwner(this, 1.6D, 10.0F, 3.0F) {
            @Override public boolean shouldExecute() { return isFollowing() && super.shouldExecute(); }
            @Override public boolean shouldContinueExecuting() { return isFollowing() && super.shouldContinueExecuting(); }
        });
        tasks.addTask(4, new EntityAIWander(this, 0.8D));
        tasks.addTask(5, new EntityAIWatchClosest(this, EntityPlayer.class, 10.0F));
        tasks.addTask(6, new EntityAILookIdle(this));
        targetTasks.addTask(0, new EntityAIOwnerHurtByTarget(this));
        targetTasks.addTask(1, new EntityAIOwnerHurtTarget(this));
        targetTasks.addTask(2, new EntityAIHurtByTarget(this, false));
        // wild and hungry: hunt animals
        targetTasks.addTask(3, new EntityAINearestAttackableTarget<EntityAnimal>(this, EntityAnimal.class, 10, true, false,
                a -> isHungry() && !isTamed() && isAdult() && !(a instanceof EntityDawnCreature)));
    }

    @Override
    public Action pickAttack() {
        int r = rand.nextInt(100);
        if (!isAdult()) return ATTACK1;
        if (r < 30) return ATTACK1;
        if (r < 60) return ATTACK2;
        if (r < 80) return RAM;
        return onGround ? GROUND : ATTACK1;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (!world.isRemote && !isLocked() && !isDawnSleeping() && !isBeingRidden() && getAttackTarget() == null && !isInWater()) {
            if (rand.nextInt(1500) == 0) startAction(ROAR);
            else if (isHungry() && rand.nextInt(700) == 0) startAction(SNIFF);
        }
    }

    @Override
    protected void onActionTick(Action a, int t) {
        if (a == ATTACK1 || a == ATTACK2) {
            if (t == 1) playSound(sound("attack"), 1.0F, getSoundPitch());
            if ((a == ATTACK1 && t == 10) || (a == ATTACK2 && t == 12)) bite(1.25F, 1.55F);
        } else if (a == RAM) {
            if (t == 1) playSound(sound("ram"), 1.0F, getSoundPitch());
            if (t == 7) {
                bite(1.15F, 2.0F);
                for (EntityLivingBase e : frontEntities(3.5D)) if (e != getAttackTarget()) damage(e, 0.7F);
            }
        } else if (a == GROUND) {
            if (t == 5) playSound(sound("attack_ground"), 1.6F, getSoundPitch());
            if (t == 12) groundSlam();
        } else if (a == ROAR) {
            if (t == 15) playSound(sound("roar"), 3.0F, getSoundPitch());
        } else if (a == SNIFF) {
            if (t == 10) playSound(sound("sniff"), 1.0F, getSoundPitch() * 0.65F);
        }
    }

    /** Bite: the AI target, or everything in front when a player rides. */
    private void bite(float playerMult, float otherMult) {
        EntityPlayer rider = getRiderPlayer();
        if (rider == null) {
            EntityLivingBase t = getAttackTarget();
            if (t != null && getDistance(t) - (width + t.width) * 0.5F <= 2.6F) hit(t, playerMult, otherMult);
        } else {
            for (EntityLivingBase t : frontEntities(4.5D)) hit(t, playerMult, otherMult);
        }
    }

    private void hit(EntityLivingBase t, float playerMult, float otherMult) {
        damage(t, t instanceof EntityPlayer ? playerMult : otherMult);
        if (isAdult()) slow(t, 180, 1);
        Vec3d look = getLookVec();
        t.motionX += look.x * 0.5D;
        t.motionZ += look.z * 0.5D;
        t.motionY += 0.25D;
        t.velocityChanged = true;
    }

    private void groundSlam() {
        EntityPlayer rider = getRiderPlayer();
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(3.5D, 2.0D, 3.5D))) {
            if (isFriendly(e, rider)) continue;
            e.attackEntityFrom(DamageSource.causeMobDamage(this), 30.0F * DAMAGE_SCALE);
            slow(e, 100, 2);
            e.motionY += 0.5D;
            e.velocityChanged = true;
        }
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, posX, posY + 0.2D, posZ, 30, 2.0D, 0.1D, 2.0D, 0.02D);
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, Block block) {
        if (isChild() || isInWater()) return;
        playSound(sound("step"), 1.0F, getSoundPitch());
        if (!world.isRemote) {
            for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(0.5D).expand(0, -0.5D, 0))) {
                if (isFriendly(e, getRiderPlayer()) || e.height / height >= 0.5F) continue;
                e.attackEntityFrom(DamageSource.causeMobDamage(this), (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * 0.45F);
            }
        }
    }
}
