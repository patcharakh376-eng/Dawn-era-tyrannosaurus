package dawnera.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

/** Chase the target, then play one of the creature's attack actions when close enough. */
public class DawnAIMelee extends EntityAIBase {
    private final EntityDawnCreature mob;
    private final double speed;
    private int repath, cooldown;

    public DawnAIMelee(EntityDawnCreature mob, double speed) {
        this.mob = mob;
        this.speed = speed;
        setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase t = mob.getAttackTarget();
        return t != null && t.isEntityAlive() && !mob.isDawnSleeping() && !mob.isSitting() && !mob.isBeingRidden();
    }

    @Override
    public boolean shouldContinueExecuting() { return shouldExecute(); }

    @Override
    public void startExecuting() { repath = 0; }

    @Override
    public void updateTask() {
        EntityLivingBase t = mob.getAttackTarget();
        if (t == null) return;
        if (cooldown > 0) cooldown--;
        mob.getLookHelper().setLookPositionWithEntity(t, 30.0F, 30.0F);
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigator().tryMoveToEntityLiving(t, speed);
        }
        float gap = mob.getDistance(t) - (mob.width + t.width) * 0.5F;
        if (gap <= 2.0F && !mob.isLocked() && cooldown <= 0) {
            mob.faceEntity(t, 60.0F, 60.0F);
            mob.startAction(mob.pickAttack());
            cooldown = 10;
        }
    }

    @Override
    public void resetTask() { mob.getNavigator().clearPath(); }
}
