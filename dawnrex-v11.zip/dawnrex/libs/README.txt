Not needed anymore: this build has no Fossils / llibrary dependency.
