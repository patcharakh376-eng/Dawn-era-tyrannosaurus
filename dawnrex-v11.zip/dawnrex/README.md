# The Dawn Era (1.12.2 port) - phase 1
Standalone: no Fossils, no llibrary. Private use only (The Dawn Era is All-Rights-Reserved).
Phase 1: shared creature core + Tyrannosaurus. Next phases: remaining creatures, items, blocks, world spawns.
