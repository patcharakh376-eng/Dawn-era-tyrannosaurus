package dawnera;

import io.netty.buffer.ByteBuf;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Server -> client: shake the camera, strongest next to (x, y, z). */
public class MessageShake implements IMessage {
    public double x, y, z;
    public float intensity, range;
    public int duration;

    public MessageShake() {}

    public MessageShake(double x, double y, double z, float intensity, int duration, float range) {
        this.x = x; this.y = y; this.z = z; this.intensity = intensity; this.duration = duration; this.range = range;
    }

    @Override public void fromBytes(ByteBuf b) {
        x = b.readDouble(); y = b.readDouble(); z = b.readDouble();
        intensity = b.readFloat(); duration = b.readInt(); range = b.readFloat();
    }

    @Override public void toBytes(ByteBuf b) {
        b.writeDouble(x); b.writeDouble(y); b.writeDouble(z);
        b.writeFloat(intensity); b.writeInt(duration); b.writeFloat(range);
    }

    public static class Handler implements IMessageHandler<MessageShake, IMessage> {
        @Override
        public IMessage onMessage(MessageShake m, MessageContext ctx) {
            dawnera.client.ClientShake.start(m.x, m.y, m.z, m.intensity, m.duration, m.range);
            return null;
        }
    }
}
