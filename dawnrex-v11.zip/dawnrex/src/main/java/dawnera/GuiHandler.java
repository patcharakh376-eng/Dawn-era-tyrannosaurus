package dawnera;

import dawnera.client.GuiDino;
import dawnera.entity.DinoContainer;
import dawnera.entity.EntityDawnCreature;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.IGuiHandler;

/** id 0 = dino menu, x = entity id. */
public class GuiHandler implements IGuiHandler {
    @Override
    public Object getServerGuiElement(int id, EntityPlayer p, World w, int x, int y, int z) {
        Entity e = w.getEntityByID(x);
        return e instanceof EntityDawnCreature ? new DinoContainer(p.inventory, (EntityDawnCreature) e) : null;
    }

    @Override
    public Object getClientGuiElement(int id, EntityPlayer p, World w, int x, int y, int z) {
        Entity e = w.getEntityByID(x);
        return e instanceof EntityDawnCreature ? new GuiDino(p.inventory, (EntityDawnCreature) e) : null;
    }
}
