package dawnera;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/** Registers one SoundEvent for every key of our own sounds.json (so new creatures need no Java here). */
@Mod.EventBusSubscriber(modid = DawnEra.MODID)
public class DawnSounds {
    private static final Map<String, SoundEvent> EVENTS = new HashMap<>();

    public static SoundEvent get(String key) {
        return EVENTS.get(key);
    }

    @SubscribeEvent
    public static void register(RegistryEvent.Register<SoundEvent> e) {
        try (InputStreamReader r = new InputStreamReader(DawnSounds.class.getResourceAsStream("/assets/" + DawnEra.MODID + "/sounds.json"), "UTF-8")) {
            JsonObject o = new JsonParser().parse(r).getAsJsonObject();
            for (Map.Entry<String, ?> en : o.entrySet()) {
                ResourceLocation rl = new ResourceLocation(DawnEra.MODID, en.getKey());
                SoundEvent se = new SoundEvent(rl).setRegistryName(rl);
                EVENTS.put(en.getKey(), se);
                e.getRegistry().register(se);
            }
        } catch (Exception ex) {
            throw new RuntimeException("dawnera: cannot read sounds.json", ex);
        }
    }
}
