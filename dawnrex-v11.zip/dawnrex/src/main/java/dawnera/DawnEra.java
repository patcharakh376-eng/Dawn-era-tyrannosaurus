package dawnera;

import dawnera.entity.EntityDawnTyrannosaurus;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeDictionary;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

/** The Dawn Era - standalone 1.12.2 port (phase 1: core + Tyrannosaurus). */
@Mod(modid = DawnEra.MODID, name = "The Dawn Era (1.12.2)", version = "1.0.0", acceptedMinecraftVersions = "[1.12.2]")
public class DawnEra {
    public static final String MODID = "dawnera";

    @Mod.Instance(MODID)
    public static DawnEra INSTANCE;

    @SidedProxy(clientSide = "dawnera.client.ClientProxy", serverSide = "dawnera.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent e) {
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "tyrannosaurus"), EntityDawnTyrannosaurus.class,
                "tyrannosaurus", 1, this, 128, 1, true, 0x4A5A2C, 0xB0A070);
        MinecraftForge.EVENT_BUS.register(new DawnEvents());
        net.minecraftforge.fml.common.network.NetworkRegistry.INSTANCE.registerGuiHandler(this, new GuiHandler());
        DawnNetwork.init();
        proxy.preInit();
    }

    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        // Dawn Era: plains + old growth taiga, spawn weight 1
        // BiomeDictionary returns unmodifiable sets: copy before merging
        Set<Biome> plains = new HashSet<>(BiomeDictionary.getBiomes(BiomeDictionary.Type.PLAINS));
        plains.addAll(BiomeDictionary.getBiomes(BiomeDictionary.Type.CONIFEROUS));
        EntityRegistry.addSpawn(EntityDawnTyrannosaurus.class, 1, 1, 1, EnumCreatureType.CREATURE, plains.toArray(new Biome[0]));
    }
}
