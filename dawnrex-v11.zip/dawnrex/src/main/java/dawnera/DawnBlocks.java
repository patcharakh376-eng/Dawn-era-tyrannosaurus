package dawnera;

import net.minecraft.block.Block;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = DawnEra.MODID)
public class DawnBlocks {
    public static final Block EGG = new BlockDinoEgg();

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Block> e) {
        e.getRegistry().register(EGG);
    }
}
