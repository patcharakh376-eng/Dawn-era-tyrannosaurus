package dawnera;

import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = DawnEra.MODID)
public class DawnItems {
    public static final Item SADDLE = new Item().setRegistryName(DawnEra.MODID, "tyrannosaurus_saddle")
            .setTranslationKey("tyrannosaurus_saddle").setCreativeTab(DawnTab.TAB).setMaxStackSize(1);
    public static final Item ARMOR = new Item().setRegistryName(DawnEra.MODID, "tyrannosaurus_armor")
            .setTranslationKey("tyrannosaurus_armor").setCreativeTab(DawnTab.TAB).setMaxStackSize(1);
    public static final Item EGG_ITEM = new ItemBlock(DawnBlocks.EGG).setRegistryName(DawnBlocks.EGG.getRegistryName());

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(SADDLE, ARMOR, EGG_ITEM);
    }
}
