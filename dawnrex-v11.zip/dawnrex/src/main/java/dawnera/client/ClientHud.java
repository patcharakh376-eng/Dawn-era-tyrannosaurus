package dawnera.client;

import dawnera.DawnEra;
import dawnera.entity.EntityDawnCreature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.Entity;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Stamina + health of the creature you ride (Dawn Era "Stamina" bar). */
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = DawnEra.MODID)
public class ClientHud {
    @SubscribeEvent
    public static void overlay(RenderGameOverlayEvent.Post e) {
        if (e.getType() != RenderGameOverlayEvent.ElementType.HOTBAR) return;
        Minecraft mc = Minecraft.getMinecraft();
        Entity m = mc.player == null ? null : mc.player.getRidingEntity();
        if (!(m instanceof EntityDawnCreature)) return;
        EntityDawnCreature d = (EntityDawnCreature) m;
        ScaledResolution r = e.getResolution();
        int x = r.getScaledWidth() / 2 - 91, w = 182;
        int y = r.getScaledHeight() - 56;
        bar(mc, x, y - 12, w, d.getHealth() / d.getMaxHealth(), 0xFFB02020, (int) d.getHealth() + " / " + (int) d.getMaxHealth());
        bar(mc, x, y, w, d.getEnergy() / d.getMaxEnergyPublic(), 0xFFE0B020, I18n.format("inspecting.dawnera.stamina") + " " + (int) d.getEnergy());
    }

    private static void bar(Minecraft mc, int x, int y, int w, float frac, int color, String label) {
        Gui.drawRect(x - 1, y - 1, x + w + 1, y + 8, 0xFF202020);
        Gui.drawRect(x, y, x + w, y + 7, 0xFF505050);
        Gui.drawRect(x, y, x + (int) (w * Math.max(0F, Math.min(1F, frac))), y + 7, color);
        mc.fontRenderer.drawStringWithShadow(label, x + 3, y, 0xFFFFFF);
    }
}
