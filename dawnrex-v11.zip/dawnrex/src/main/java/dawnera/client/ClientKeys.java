package dawnera.client;

import dawnera.DawnEra;
import dawnera.DawnNetwork;
import dawnera.MessageInput;
import dawnera.entity.EntityDawnCreature;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.RayTraceResult;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.client.settings.KeyConflictContext;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

/**
 * Dawn Era InputControls: attack = left mouse (40 tick cooldown), roar = right mouse (40), attack_ground = space (40).
 * Detected by polling (the vanilla attack/use keys share the same buttons). Also the "open interact menu" key and
 * the third-person camera zoom (PassengerZoom).
 */
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = DawnEra.MODID)
public class ClientKeys {
    public static final String CAT = "key.categories.dawnera";
    public static final KeyBinding ATTACK = new KeyBinding("key.dawnera.attack", KeyConflictContext.IN_GAME, -100, CAT);
    public static final KeyBinding ROAR = new KeyBinding("key.dawnera.roar", KeyConflictContext.IN_GAME, -99, CAT);
    public static final KeyBinding GROUND = new KeyBinding("key.dawnera.attack_ground", KeyConflictContext.IN_GAME, Keyboard.KEY_SPACE, CAT);
    public static final KeyBinding MENU = new KeyBinding("key.dawnera.open_menu", KeyConflictContext.IN_GAME, Keyboard.KEY_G, CAT);

    private static final KeyBinding[] KEYS = {ATTACK, ROAR, GROUND};
    private static final int COOLDOWN = 40;
    /** Extra third-person distance while riding, so the whole creature is visible. */
    private static final float ZOOM = 4.5F;
    private static final int[] cooldown = new int[3];
    private static final boolean[] was = new boolean[4];
    private static boolean wasRiding;
    private static int previousView;

    public static void register() {
        ClientRegistry.registerKeyBinding(ATTACK);
        ClientRegistry.registerKeyBinding(ROAR);
        ClientRegistry.registerKeyBinding(GROUND);
        ClientRegistry.registerKeyBinding(MENU);
    }

    private static boolean down(KeyBinding kb) {
        int c = kb.getKeyCode();
        return c < 0 ? Mouse.isButtonDown(c + 100) : Keyboard.isKeyDown(c);
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayerSP p = mc.player;
        if (p == null) return;
        Entity mount = p.getRidingEntity();
        boolean riding = mount instanceof EntityDawnCreature;
        // switch to the third-person back view when mounting, and restore the previous view when dismounting
        if (riding && !wasRiding) { previousView = mc.gameSettings.thirdPersonView; if (previousView == 0) mc.gameSettings.thirdPersonView = 1; }
        if (!riding && wasRiding) mc.gameSettings.thirdPersonView = previousView;
        wasRiding = riding;

        for (int i = 0; i < 3; i++) if (cooldown[i] > 0) cooldown[i]--;
        boolean free = mc.currentScreen == null;
        for (int i = 0; i < 3; i++) {
            boolean now = free && riding && down(KEYS[i]);
            if (now && !was[i] && cooldown[i] <= 0) {
                DawnNetwork.NET.sendToServer(new MessageInput(i, mount.getEntityId()));
                cooldown[i] = COOLDOWN;
            }
            was[i] = now;
        }

        boolean menuNow = free && down(MENU);
        if (menuNow && !was[3]) {
            int id = -1;
            if (riding) id = mount.getEntityId();
            else if (mc.objectMouseOver != null && mc.objectMouseOver.typeOfHit == RayTraceResult.Type.ENTITY
                    && mc.objectMouseOver.entityHit instanceof EntityDawnCreature) id = mc.objectMouseOver.entityHit.getEntityId();
            if (id >= 0) DawnNetwork.NET.sendToServer(new MessageInput(3, id));
        }
        was[3] = menuNow;
    }

    /** PassengerZoom: pull the third-person camera back while riding. */
    @SubscribeEvent
    public static void camera(EntityViewRenderEvent.CameraSetup e) {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.player != null && mc.player.getRidingEntity() instanceof EntityDawnCreature && mc.gameSettings.thirdPersonView == 1) {
            GlStateManager.translate(0.0F, 0.0F, -ZOOM);
        }
    }
}
