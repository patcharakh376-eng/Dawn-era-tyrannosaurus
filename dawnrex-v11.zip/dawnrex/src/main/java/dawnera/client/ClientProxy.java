package dawnera.client;

import dawnera.CommonProxy;
import dawnera.entity.EntityDawnTyrannosaurus;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        ClientKeys.register();
        RenderingRegistry.registerEntityRenderingHandler(EntityDawnTyrannosaurus.class, rm -> new RenderDawnCreature<EntityDawnTyrannosaurus>(rm, 1.8F));
    }
}
