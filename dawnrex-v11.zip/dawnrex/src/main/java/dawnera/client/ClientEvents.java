package dawnera.client;

import dawnera.DawnEra;
import dawnera.DawnItems;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = DawnEra.MODID)
public class ClientEvents {
    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (Item i : new Item[]{DawnItems.SADDLE, DawnItems.ARMOR, DawnItems.EGG_ITEM}) {
            ModelLoader.setCustomModelResourceLocation(i, 0, new ModelResourceLocation(i.getRegistryName(), "inventory"));
        }
    }
}
