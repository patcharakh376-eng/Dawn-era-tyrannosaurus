package dawnera.client;

import dawnera.DawnEra;
import java.util.Random;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Camera shake for stomps, roars and slams (decays over its duration, weaker with distance). */
@SideOnly(Side.CLIENT)
@Mod.EventBusSubscriber(value = Side.CLIENT, modid = DawnEra.MODID)
public class ClientShake {
    private static final Random RAND = new Random();
    private static float intensity;
    private static int ticks, total;

    public static void start(double x, double y, double z, float inten, int dur, float range) {
        Minecraft.getMinecraft().addScheduledTask(() -> {
            EntityPlayer p = Minecraft.getMinecraft().player;
            if (p == null) return;
            float f = (float) Math.max(0.0D, 1.0D - p.getDistance(x, y, z) / range);
            float v = inten * f;
            float current = total > 0 ? intensity * ticks / (float) total : 0F;
            if (v > current) { intensity = v; ticks = dur; total = dur; }
        });
    }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase == TickEvent.Phase.END && ticks > 0) ticks--;
    }

    @SubscribeEvent
    public static void camera(EntityViewRenderEvent.CameraSetup e) {
        if (ticks <= 0 || total <= 0) return;
        float k = intensity * ticks / (float) total;
        e.setYaw(e.getYaw() + (RAND.nextFloat() - 0.5F) * 2F * k);
        e.setPitch(e.getPitch() + (RAND.nextFloat() - 0.5F) * 2F * k);
        e.setRoll(e.getRoll() + (RAND.nextFloat() - 0.5F) * 1.2F * k);
    }
}
