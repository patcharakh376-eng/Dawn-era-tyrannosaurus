package dawnera.client;

import dawnera.entity.DinoContainer;
import dawnera.entity.EntityDawnCreature;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.client.resources.I18n;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.inventory.Slot;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Menu of a tamed creature: preview, saddle/armor slots, follow/sit buttons and status bars. */
@SideOnly(Side.CLIENT)
public class GuiDino extends GuiContainer {
    private final EntityDawnCreature dino;
    private GuiButton follow, sit, mount;

    public GuiDino(InventoryPlayer inv, EntityDawnCreature dino) {
        super(new DinoContainer(inv, dino));
        this.dino = dino;
        this.xSize = 176;
        this.ySize = 214;
    }

    @Override
    public void initGui() {
        super.initGui();
        follow = new GuiButton(0, guiLeft + 96, guiTop + 15, 72, 16, "");
        sit = new GuiButton(1, guiLeft + 96, guiTop + 32, 72, 16, "");
        mount = new GuiButton(2, guiLeft + 96, guiTop + 49, 72, 16, "");
        buttonList.add(follow);
        buttonList.add(sit);
        buttonList.add(mount);
    }

    @Override
    public void updateScreen() {
        super.updateScreen();
        follow.displayString = I18n.format(dino.isFollowing() ? "gui.dawnera.wander" : "gui.dawnera.follow");
        sit.displayString = I18n.format(dino.isSitting() ? "gui.dawnera.stand" : "gui.dawnera.sit");
        mount.displayString = I18n.format(dino.isPrivateMount() ? "gui.dawnera.private" : "gui.dawnera.public");
        if (!dino.isEntityAlive()) mc.player.closeScreen();
    }

    @Override
    protected void actionPerformed(GuiButton b) {
        mc.playerController.sendEnchantPacket(inventorySlots.windowId, b.id);
    }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawDefaultBackground();
        super.drawScreen(mx, my, pt);
        renderHoveredToolTip(mx, my);
    }

    private void bar(int x, int y, int w, float frac, int color, String label) {
        drawRect(x - 1, y - 1, x + w + 1, y + 9, 0xFF303030);
        drawRect(x, y, x + w, y + 8, 0xFF606060);
        drawRect(x, y, x + (int) (w * Math.max(0F, Math.min(1F, frac))), y + 8, color);
        fontRenderer.drawStringWithShadow(label, x + 3, y, 0xFFFFFF);
    }

    @Override
    protected void drawGuiContainerBackgroundLayer(float pt, int mx, int my) {
        int l = guiLeft, t = guiTop;
        drawRect(l, t, l + xSize, t + ySize, 0xFF000000);
        drawRect(l + 1, t + 1, l + xSize - 1, t + ySize - 1, 0xFFC6C6C6);
        drawRect(l + 7, t + 15, l + 90, t + 84, 0xFF555555);   // preview frame
        drawRect(l + 8, t + 16, l + 89, t + 83, 0xFF9AB5D6);
        for (Slot s : inventorySlots.inventorySlots) {
            drawRect(l + s.xPos - 1, t + s.yPos - 1, l + s.xPos + 17, t + s.yPos + 17, 0xFF8B8B8B);
            drawRect(l + s.xPos, t + s.yPos, l + s.xPos + 16, t + s.yPos + 16, 0xFF373737);
        }
        GuiInventory.drawEntityOnScreen(l + 48, t + 80, 8, l + 48 - mx, t + 40 - my, dino);
        bar(l + 8, t + 96, 160, dino.getHealth() / dino.getMaxHealth(), 0xFFB02020,
                I18n.format("gui.dawnera.health") + " " + (int) dino.getHealth() + " / " + (int) dino.getMaxHealth());
        bar(l + 8, t + 107, 160, dino.getHunger() / dino.getMaxHungerPublic(), 0xFFC8821E,
                I18n.format("gui.dawnera.hunger") + " " + (int) dino.getHunger() + " / " + (int) dino.getMaxHungerPublic());
        bar(l + 8, t + 118, 160, dino.getGrowthProgress(), 0xFF3C9B3C,
                I18n.format("gui.dawnera.growth") + " " + (int) (dino.getGrowthProgress() * 100) + "%");
    }

    @Override
    protected void drawGuiContainerForegroundLayer(int mx, int my) {
        fontRenderer.drawString(dino.getDisplayName().getUnformattedText(), 8, 5, 0x404040);
        fontRenderer.drawString(I18n.format("gui.dawnera.gear"), 96, 88 - 9, 0x404040);
        fontRenderer.drawString(I18n.format(dino.isMale() ? "gui.dawnera.male" : "gui.dawnera.female"), 8, 88 - 3, 0x404040);
    }
}
