package dawnera;

import dawnera.entity.EntityDawnTyrannosaurus;
import java.util.Random;
import net.minecraft.block.Block;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.properties.IProperty;
import net.minecraft.block.properties.PropertyInteger;
import net.minecraft.block.state.BlockStateContainer;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;
import net.minecraft.util.BlockRenderLayer;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockAccess;
import net.minecraft.world.World;

/** Tyrannosaurus egg: needs warmth to develop (warm biome or a nearby heat source), then hatches a baby. */
public class BlockDinoEgg extends Block {
    public static final PropertyInteger STAGE = PropertyInteger.create("stage", 0, 2);
    private static final AxisAlignedBB BOX = new AxisAlignedBB(0.1875D, 0.0D, 0.1875D, 0.8125D, 0.875D, 0.8125D);
    /** Ticks between development steps (3 steps = about 3 minutes when warm). */
    private static final int STEP_TICKS = 1200;

    public BlockDinoEgg() {
        super(Material.ROCK);
        setRegistryName(DawnEra.MODID, "tyrannosaurus_egg");
        setTranslationKey("tyrannosaurus_egg");
        setHardness(0.5F);
        setSoundType(SoundType.STONE);
        setCreativeTab(DawnTab.TAB);
        setDefaultState(blockState.getBaseState().withProperty(STAGE, 0));
    }

    @Override protected BlockStateContainer createBlockState() { return new BlockStateContainer(this, new IProperty[]{STAGE}); }
    @Override public int getMetaFromState(IBlockState s) { return s.getValue(STAGE); }
    @Override public IBlockState getStateFromMeta(int meta) { return getDefaultState().withProperty(STAGE, Math.min(2, meta)); }
    @Override public boolean isOpaqueCube(IBlockState s) { return false; }
    @Override public boolean isFullCube(IBlockState s) { return false; }
    @Override public AxisAlignedBB getBoundingBox(IBlockState s, IBlockAccess w, BlockPos p) { return BOX; }
    @Override public BlockRenderLayer getRenderLayer() { return BlockRenderLayer.CUTOUT; }

    private boolean supported(World w, BlockPos pos) { return w.isSideSolid(pos.down(), EnumFacing.UP); }

    @Override
    public boolean canPlaceBlockAt(World w, BlockPos pos) { return super.canPlaceBlockAt(w, pos) && supported(w, pos); }

    @Override
    public void onBlockAdded(World w, BlockPos pos, IBlockState s) {
        if (!w.isRemote) w.scheduleUpdate(pos, this, STEP_TICKS);
    }

    @Override
    public void neighborChanged(IBlockState s, World w, BlockPos pos, Block b, BlockPos from) {
        if (!supported(w, pos)) {
            dropBlockAsItem(w, pos, s, 0);
            w.setBlockToAir(pos);
        }
    }

    @Override
    public void updateTick(World w, BlockPos pos, IBlockState s, Random rand) {
        if (w.isRemote) return;
        if (warm(w, pos)) {
            int stage = s.getValue(STAGE);
            if (stage >= 2) {
                hatch(w, pos);
                return;
            }
            w.setBlockState(pos, s.withProperty(STAGE, stage + 1), 2);
        }
        w.scheduleUpdate(pos, this, STEP_TICKS);
    }

    private boolean warm(World w, BlockPos pos) {
        if (w.getBiome(pos).getTemperature(pos) >= 0.6F) return true;
        for (BlockPos p : BlockPos.getAllInBox(pos.add(-3, -2, -3), pos.add(3, 2, 3))) {
            Block b = w.getBlockState(p).getBlock();
            if (b == Blocks.FIRE || b == Blocks.LAVA || b == Blocks.FLOWING_LAVA || b == Blocks.TORCH
                    || b == Blocks.LIT_FURNACE || b == Blocks.MAGMA || b == Blocks.GLOWSTONE) return true;
        }
        return false;
    }

    private void hatch(World w, BlockPos pos) {
        w.setBlockToAir(pos);
        EntityDawnTyrannosaurus baby = new EntityDawnTyrannosaurus(w);
        baby.setLocationAndAngles(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, w.rand.nextFloat() * 360.0F, 0.0F);
        baby.setAge(0);
        w.spawnEntity(baby);
        w.playSound(null, pos, net.minecraft.init.SoundEvents.ENTITY_CHICKEN_EGG, net.minecraft.util.SoundCategory.BLOCKS, 1.0F, 0.6F);
    }
}
