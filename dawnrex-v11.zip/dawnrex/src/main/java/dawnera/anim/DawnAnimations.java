package dawnera.anim;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.Reader;
import java.util.*;

/** Minimal Bedrock animation.json reader/sampler (linear + catmullrom). Replaces the AstemirLib animator. */
public class DawnAnimations {
    public static class Channel {
        float[] t; float[][] v; boolean[] cr;
    }
    public static class BoneAnim { public Channel rot, pos, scl; }
    public static class Anim {
        public String name; public float length; public boolean loop, hold;
        public Map<String, BoneAnim> bones = new HashMap<>();
    }

    public static Map<String, Anim> parse(Reader r) {
        Map<String, Anim> out = new HashMap<>();
        JsonObject root = new JsonParser().parse(r).getAsJsonObject().getAsJsonObject("animations");
        for (Map.Entry<String, JsonElement> e : root.entrySet()) {
            JsonObject o = e.getValue().getAsJsonObject();
            Anim a = new Anim();
            a.name = e.getKey();
            a.length = o.has("animation_length") ? o.get("animation_length").getAsFloat() : 0f;
            if (o.has("loop")) {
                JsonElement l = o.get("loop");
                if (l.isJsonPrimitive() && l.getAsJsonPrimitive().isBoolean()) a.loop = l.getAsBoolean();
                else a.hold = "hold_on_last_frame".equals(l.getAsString());
            }
            if (o.has("bones")) {
                for (Map.Entry<String, JsonElement> b : o.getAsJsonObject("bones").entrySet()) {
                    BoneAnim ba = new BoneAnim();
                    JsonObject bo = b.getValue().getAsJsonObject();
                    if (bo.has("rotation")) ba.rot = channel(bo.get("rotation"));
                    if (bo.has("position")) ba.pos = channel(bo.get("position"));
                    if (bo.has("scale")) ba.scl = channel(bo.get("scale"));
                    a.bones.put(b.getKey(), ba);
                }
            }
            out.put(a.name, a);
        }
        return out;
    }

    private static float[] vec(JsonElement el) {
        if (el.isJsonArray()) {
            JsonArray ar = el.getAsJsonArray();
            return new float[]{ar.get(0).getAsFloat(), ar.get(1).getAsFloat(), ar.get(2).getAsFloat()};
        }
        float n = el.getAsFloat();
        return new float[]{n, n, n};
    }

    private static Channel channel(JsonElement el) {
        Channel c = new Channel();
        if (!el.isJsonObject()) {
            c.t = new float[]{0}; c.v = new float[][]{vec(el)}; c.cr = new boolean[]{false};
            return c;
        }
        TreeMap<Float, JsonElement> sorted = new TreeMap<>();
        for (Map.Entry<String, JsonElement> k : el.getAsJsonObject().entrySet()) sorted.put(Float.parseFloat(k.getKey()), k.getValue());
        int n = sorted.size();
        c.t = new float[n]; c.v = new float[n][]; c.cr = new boolean[n];
        int i = 0;
        for (Map.Entry<Float, JsonElement> k : sorted.entrySet()) {
            c.t[i] = k.getKey();
            JsonElement kf = k.getValue();
            if (kf.isJsonObject()) {
                JsonObject ko = kf.getAsJsonObject();
                c.v[i] = vec(ko.has("post") ? ko.get("post") : ko.get("pre"));
                c.cr[i] = ko.has("lerp_mode") && "catmullrom".equals(ko.get("lerp_mode").getAsString());
            } else {
                c.v[i] = vec(kf);
            }
            i++;
        }
        return c;
    }

    /** Time wrapped/clamped according to the animation's loop mode. */
    public static float localTime(Anim a, float time) {
        if (a.length <= 0f) return 0f;
        if (a.loop) return time % a.length;
        return Math.min(time, a.length);
    }

    public static void sample(Channel c, float time, float[] out) {
        int n = c.t.length;
        if (n == 1 || time <= c.t[0]) { System.arraycopy(c.v[0], 0, out, 0, 3); return; }
        if (time >= c.t[n - 1]) { System.arraycopy(c.v[n - 1], 0, out, 0, 3); return; }
        int i = 0;
        while (i < n - 2 && time >= c.t[i + 1]) i++;
        float u = (time - c.t[i]) / (c.t[i + 1] - c.t[i]);
        float[] p1 = c.v[i], p2 = c.v[i + 1];
        if (c.cr[i] || c.cr[i + 1]) {
            float[] p0 = c.v[Math.max(i - 1, 0)], p3 = c.v[Math.min(i + 2, n - 1)];
            for (int k = 0; k < 3; k++) {
                out[k] = 0.5f * ((2 * p1[k]) + (-p0[k] + p2[k]) * u
                        + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * u * u
                        + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * u * u * u);
            }
        } else {
            for (int k = 0; k < 3; k++) out[k] = p1[k] + (p2[k] - p1[k]) * u;
        }
    }
}
