package dawnera;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.ItemMonsterPlacer;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Dedicated creative tab "The Dawn Era" with its own search box. */
public class DawnTab extends CreativeTabs {
    public static final CreativeTabs TAB = new DawnTab();

    private DawnTab() { super("dawnera"); }

    @Override
    @SideOnly(Side.CLIENT)
    public ItemStack createIcon() { return new ItemStack(DawnItems.EGG_ITEM); }

    @Override
    public boolean hasSearchBar() { return true; }

    @Override
    public String getBackgroundImageName() { return "item_search.png"; }

    @Override
    public int getSearchbarWidth() { return 89; }

    @Override
    @SideOnly(Side.CLIENT)
    public void displayAllRelevantItems(NonNullList<ItemStack> list) {
        ItemStack egg = new ItemStack(Items.SPAWN_EGG);
        ItemMonsterPlacer.applyEntityIdToItemStack(egg, new ResourceLocation(DawnEra.MODID, "tyrannosaurus"));
        list.add(egg);
        super.displayAllRelevantItems(list);
    }
}
