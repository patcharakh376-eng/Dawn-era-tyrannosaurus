package dawnera;

import dawnera.entity.EntityDawnCreature;
import io.netty.buffer.ByteBuf;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraftforge.fml.common.network.simpleimpl.IMessage;
import net.minecraftforge.fml.common.network.simpleimpl.IMessageHandler;
import net.minecraftforge.fml.common.network.simpleimpl.MessageContext;

/** Client -> server: rider input (0 attack, 1 roar, 2 attack_ground) or 3 = open the creature menu (entityId). */
public class MessageInput implements IMessage {
    private static final String[] NAMES = {"attack", "roar", "attack_ground"};
    public int id, entityId;

    public MessageInput() {}
    public MessageInput(int id, int entityId) { this.id = id; this.entityId = entityId; }

    @Override public void fromBytes(ByteBuf b) { id = b.readInt(); entityId = b.readInt(); }
    @Override public void toBytes(ByteBuf b) { b.writeInt(id); b.writeInt(entityId); }

    public static class Handler implements IMessageHandler<MessageInput, IMessage> {
        @Override
        public IMessage onMessage(MessageInput m, MessageContext ctx) {
            EntityPlayerMP p = ctx.getServerHandler().player;
            p.getServerWorld().addScheduledTask(() -> {
                Entity mount = p.getRidingEntity();
                if (m.id >= 0 && m.id <= 2) {
                    if (mount instanceof EntityDawnCreature && ((EntityDawnCreature) mount).getControllingPassenger() == p) {
                        ((EntityDawnCreature) mount).riderInput(NAMES[m.id]);
                    }
                } else if (m.id == 3) {
                    Entity e = mount instanceof EntityDawnCreature ? mount : p.world.getEntityByID(m.entityId);
                    if (e instanceof EntityDawnCreature) {
                        EntityDawnCreature d = (EntityDawnCreature) e;
                        if (d.isTamed() && d.isOwner(p) && p.getDistanceSq(d) < 144.0D) {
                            p.openGui(DawnEra.INSTANCE, 0, p.world, d.getEntityId(), 0, 0);
                        }
                    }
                }
            });
            return null;
        }
    }
}
