package dawnera.entity;

import java.util.List;
import net.minecraft.entity.ai.EntityAIBase;

/** The in-love female walks to the nearest in-love adult male of her species, then lays an egg. */
public class DawnAIMate extends EntityAIBase {
    private final EntityDawnCreature mob;
    private EntityDawnCreature partner;
    private int repath;

    public DawnAIMate(EntityDawnCreature mob) {
        this.mob = mob;
        setMutexBits(3);
    }

    private EntityDawnCreature findPartner() {
        List<? extends EntityDawnCreature> list = mob.world.getEntitiesWithinAABB(mob.getClass(), mob.getEntityBoundingBox().grow(24.0D, 8.0D, 24.0D));
        EntityDawnCreature best = null;
        double bd = Double.MAX_VALUE;
        for (EntityDawnCreature e : list) {
            if (e == mob || !e.isMale() || !e.isInLove() || !e.isAdult() || !e.isEntityAlive()) continue;
            double d = mob.getDistanceSq(e);
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }

    @Override
    public boolean shouldExecute() {
        if (mob.isMale() || !mob.isInLove() || !mob.isAdult() || mob.isSitting() || mob.isDawnSleeping()) return false;
        partner = findPartner();
        return partner != null;
    }

    @Override
    public boolean shouldContinueExecuting() {
        return partner != null && partner.isEntityAlive() && partner.isInLove() && mob.isInLove();
    }

    @Override
    public void updateTask() {
        mob.getLookHelper().setLookPositionWithEntity(partner, 10.0F, mob.getVerticalFaceSpeed());
        if (--repath <= 0) {
            repath = 10;
            mob.getNavigator().tryMoveToEntityLiving(partner, 1.0D);
        }
        if (mob.getDistance(partner) - (mob.width + partner.width) * 0.5F < 2.5F) {
            mob.mateWith(partner);
            partner = null;
        }
    }

    @Override
    public void resetTask() {
        partner = null;
        mob.getNavigator().clearPath();
    }
}
