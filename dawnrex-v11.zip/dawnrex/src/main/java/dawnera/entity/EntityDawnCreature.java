package dawnera.entity;

import dawnera.DawnEra;
import dawnera.DawnItems;
import dawnera.DawnNetwork;
import dawnera.DawnSounds;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.block.material.Material;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.MoverType;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Shared core for every Dawn Era creature on 1.12.2: growth, gender, hunger, energy (stamina), the Dawn Era
 * rest/sleep state machine, taming, breeding (egg), saddle + armor, Dawn Era riding, and an action state machine
 * (replacement for AstemirLib ActionState).
 */
public abstract class EntityDawnCreature extends EntityTameable {
    /** One playable action (attack, roar, ...). length is in ticks. */
    public static class Action {
        public final String id, anim;
        public final int length;
        public Action(String id, String anim, int length) { this.id = id; this.anim = anim; this.length = length; }
    }

    /** Rest transitions (Dawn Era actions down / fall_asleep / wake_up / up), index = TRANS id. */
    public static final String[] TRANS_ANIM = {"", "animation.model.down", "animation.model.fall_asleep", "animation.model.wake_up", "animation.model.up"};
    public static final int[] TRANS_LEN = {0, 31, 60, 75, 45};

    private static final DataParameter<Integer> ACTION = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> SADDLED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> ARMORED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> MALE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    /** 0 standing, 1 resting (sitting), 2 sleeping. */
    private static final DataParameter<Integer> REST = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    /** 0 none, else the transition currently playing (see TRANS_ANIM). */
    private static final DataParameter<Integer> TRANS = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Integer> AGE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> FOLLOW = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> PRIVATE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Float> HUNGER = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.FLOAT);
    private static final DataParameter<Float> ENERGY = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.FLOAT);
    private static final UUID ARMOR_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a12");
    private static final UUID ARMOR_HP_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a13");
    private static final UUID MALE_ARMOR_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a15");
    private static final UUID ARMOR_TOUGH_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a14");

    /** Wearing the armor item: +20 armor, +30 max health, +5 armor toughness. */
    protected static final double ARMOR_BONUS = 20.0D;
    protected static final double ARMOR_HP_BONUS = 30.0D;
    protected static final double ARMOR_TOUGHNESS_BONUS = 5.0D;
    /** Multiplier for all attack damage (Dawn Era values are very high). */
    protected static final float DAMAGE_SCALE = 1.0F;
    /** Dawn Era tyrannosaurus.json: RidingSpeed 0.2, RidingSprintSpeed 1.8. */
    /** 1.12.2 ground physics differ from 1.20.1: these give about 4.5 blocks/s walking and 9 blocks/s sprinting. */
    protected static final float RIDING_SPEED = 0.45F;
    protected static final float RIDING_SPRINT_SPEED = 0.9F;
    /** Water acceleration (Dawn Era SwimSpeed 2.0 doubles vanilla 0.02). */
    protected static final float SWIM_ACCELERATION = 0.045F;

    public int actionTick;
    public int transTick;
    public int breedCooldown;
    protected int tickControlled;
    private int sleepCooldown;
    private int noSleepTicks;
    private int energyBlock;
    private float lastScale = -1F;

    // client-side animation state (plain data, read only by the renderer)
    public String animCur = "";
    public String animPrev = "";
    public float animCurTime, animPrevTime, animChangeAt;

    protected EntityDawnCreature(World world) {
        super(world);
        this.stepHeight = 2.0F;
    }

    // ------------------------------------------------------------ species data (implemented by each creature)

    public abstract String getSpeciesId();
    protected abstract Action[] getActions();
    protected abstract float getBaseWidth();
    protected abstract float getBaseHeight();
    /** Ticks until fully grown. */
    protected abstract int getAdultAgeTicks();
    protected abstract float getMaxHunger();
    protected abstract float getAdultMaxHealth();
    public abstract Action pickAttack();
    /** Server-side: called once per tick while an action plays. t = ticks since the action started. */
    protected abstract void onActionTick(Action a, int t);
    /** Female lays her egg (placed block / item). */
    protected abstract void layEgg();
    /** Rider key: "attack", "roar" or "attack_ground" (already validated: controlled 20+ ticks, idle, not resting). */
    protected abstract void onRiderInput(String id);
    protected float getMaxEnergy() { return 1000.0F; }
    /** Extra armor the male has over the female. */
    protected double getMaleArmorBonus() { return 0.0D; }
    /** Health restored when this creature kills something by itself. */
    protected float getKillHeal() { return 30.0F; }
    @Nullable protected Action getEatAction() { return null; }

    // ------------------------------------------------------------ data

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(ACTION, 0);
        dataManager.register(SADDLED, false);
        dataManager.register(ARMORED, false);
        dataManager.register(MALE, true);
        dataManager.register(REST, 0);
        dataManager.register(TRANS, 0);
        dataManager.register(AGE, Integer.MAX_VALUE / 2);
        dataManager.register(HUNGER, 100F);
        dataManager.register(ENERGY, 1000F);
        dataManager.register(FOLLOW, true);
        dataManager.register(PRIVATE, true);
    }

    /** Call at the end of each species constructor. */
    protected void initDefaults() {
        setSize(getBaseWidth(), getBaseHeight());
        dataManager.set(MALE, rand.nextBoolean());
        dataManager.set(HUNGER, getMaxHunger());
        dataManager.set(ENERGY, getMaxEnergy());
        setHealth(getMaxHealth());
    }

    public boolean isMale() { return dataManager.get(MALE); }
    public int getAge() { return dataManager.get(AGE); }
    public void setAge(int ticks) { dataManager.set(AGE, ticks); }
    public boolean isAdult() { return getAge() >= getAdultAgeTicks(); }
    @Override public boolean isChild() { return !isAdult(); }
    public float getGrowthProgress() { return Math.min(1.0F, getAge() / (float) getAdultAgeTicks()); }
    public float getHunger() { return dataManager.get(HUNGER); }
    public float getMaxHungerPublic() { return getMaxHunger(); }
    public boolean isHungry() { return getHunger() < getMaxHunger() * 0.6F; }
    public int getRestState() { return dataManager.get(REST); }
    public int getTrans() { return dataManager.get(TRANS); }
    /** Sitting, lying down or sleeping, including the transitions between them. */
    public boolean isResting() { return getRestState() != 0 || getTrans() != 0; }
    public boolean isDawnSleeping() { return getRestState() == 2 || getTrans() == 2; }
    public boolean isFollowing() { return dataManager.get(FOLLOW); }
    public void setFollowing(boolean v) { dataManager.set(FOLLOW, v); }
    public boolean isPrivateMount() { return dataManager.get(PRIVATE); }
    public void setPrivateMount(boolean v) { dataManager.set(PRIVATE, v); }
    /** Sit / stand command. Both the AI flag and the real sitting flag are set, and a stand command wins over auto-sleep. */
    public void toggleSit() {
        boolean v = !isSitting();
        aiSit.setSitting(v);
        setSitting(v);
        isJumping = false;
        navigator.clearPath();
        setAttackTarget(null);
        if (!v) requestStand();
    }

    /** The player told it to get up (or follow): stand up now and do not fall asleep again for a while. */
    public void requestStand() {
        noSleepTicks = 3000;
        sleepCooldown = 0;
    }
    public boolean isSaddled() { return dataManager.get(SADDLED); }
    public boolean isArmored() { return dataManager.get(ARMORED); }
    public void setSaddled(boolean v) { dataManager.set(SADDLED, v); }
    public float getEnergy() { return dataManager.get(ENERGY); }
    public float getMaxEnergyPublic() { return getMaxEnergy(); }

    public boolean consumeEnergy(float e) {
        if (getEnergy() >= e) {
            dataManager.set(ENERGY, getEnergy() - e);
            energyBlock = 10;
            return true;
        }
        return false;
    }

    public void setArmored(boolean v) { setArmored(v, true); }

    public void setArmored(boolean v, boolean heal) {
        dataManager.set(ARMORED, v);
        if (world.isRemote) return;
        modifier(SharedMonsterAttributes.ARMOR, ARMOR_UUID, "dawnera armor", ARMOR_BONUS, v);
        modifier(SharedMonsterAttributes.ARMOR_TOUGHNESS, ARMOR_TOUGH_UUID, "dawnera armor toughness", ARMOR_TOUGHNESS_BONUS, v);
        modifier(SharedMonsterAttributes.MAX_HEALTH, ARMOR_HP_UUID, "dawnera armor health", ARMOR_HP_BONUS, v);
        if (v && heal) setHealth(getHealth() + (float) ARMOR_HP_BONUS);
        else if (getHealth() > getMaxHealth()) setHealth(getMaxHealth());
    }

    private void modifier(IAttribute attr, UUID id, String name, double value, boolean on) {
        IAttributeInstance inst = getEntityAttribute(attr);
        if (inst.getModifier(id) != null) inst.removeModifier(id);
        if (on) inst.applyModifier(new AttributeModifier(id, name, value, 0));
    }

    /** Baby is weak (10% health), adult is full strength. */
    private void updateGrowthStats() {
        modifier(SharedMonsterAttributes.ARMOR, MALE_ARMOR_UUID, "dawnera male armor", getMaleArmorBonus(), isMale() && getMaleArmorBonus() > 0.0D);
        double target = getAdultMaxHealth() * (0.1D + 0.9D * getGrowthProgress());
        IAttributeInstance hp = getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        if (Math.abs(hp.getBaseValue() - target) > 0.5D) {
            float ratio = getHealth() / getMaxHealth();
            hp.setBaseValue(target);
            setHealth(Math.min(getMaxHealth(), ratio * getMaxHealth()));
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setInteger("DawnAge", getAge());
        c.setFloat("DawnHunger", getHunger());
        c.setFloat("DawnEnergy", getEnergy());
        c.setBoolean("DawnMale", isMale());
        c.setBoolean("DawnSaddled", isSaddled());
        c.setBoolean("DawnArmored", isArmored());
        c.setBoolean("DawnFollow", isFollowing());
        c.setBoolean("DawnPrivate", isPrivateMount());
        c.setInteger("DawnRest", getRestState());
        c.setInteger("DawnBreedCooldown", breedCooldown);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        if (c.hasKey("DawnAge")) setAge(c.getInteger("DawnAge"));
        if (c.hasKey("DawnHunger")) dataManager.set(HUNGER, c.getFloat("DawnHunger"));
        if (c.hasKey("DawnEnergy")) dataManager.set(ENERGY, c.getFloat("DawnEnergy"));
        if (c.hasKey("DawnMale")) dataManager.set(MALE, c.getBoolean("DawnMale"));
        setSaddled(c.getBoolean("DawnSaddled"));
        setArmored(c.getBoolean("DawnArmored"), false);
        if (c.hasKey("DawnFollow")) setFollowing(c.getBoolean("DawnFollow"));
        if (c.hasKey("DawnPrivate")) setPrivateMount(c.getBoolean("DawnPrivate"));
        if (c.hasKey("DawnRest")) dataManager.set(REST, c.getInteger("DawnRest"));
        breedCooldown = c.getInteger("DawnBreedCooldown");
    }

    // ------------------------------------------------------------ actions

    public Action getAction() {
        int i = dataManager.get(ACTION);
        Action[] all = getActions();
        return i > 0 && i <= all.length ? all[i - 1] : null;
    }

    public boolean isLocked() { return getAction() != null; }

    public void startAction(Action a) { startAction(a, false); }

    public void startAction(Action a, boolean force) {
        if (world.isRemote || a == null) return;
        if (!force && getAction() != null) return;
        Action[] all = getActions();
        for (int i = 0; i < all.length; i++) {
            if (all[i] == a) {
                dataManager.set(ACTION, i + 1);
                actionTick = 0;
                return;
            }
        }
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        super.notifyDataManagerChange(key);
        if (ACTION.equals(key)) actionTick = 0;
        if (TRANS.equals(key)) transTick = 0;
    }

    /** Called by the input packet (rider pressed attack / roar / ground attack). */
    public void riderInput(String id) {
        if (tickControlled >= 20 && getAction() == null && !isResting() && !isInWater() && getControllingPassenger() != null) {
            onRiderInput(id);
        }
    }

    // ------------------------------------------------------------ rest / sleep (Dawn Era BaseSleepingAnimal)

    private void startTrans(int t) {
        dataManager.set(TRANS, t);
        transTick = 0;
        motionX = 0.0D;
        motionZ = 0.0D;
        if (t == 2) playDawn("yawn", 1.0F, 1.0F);
    }

    private void endTrans(int t) {
        dataManager.set(REST, t == 1 ? 1 : (t == 2 ? 2 : (t == 3 ? 1 : 0)));
        dataManager.set(TRANS, 0);
        transTick = 0;
        sleepCooldown = 20 + rand.nextInt(20);
    }

    private void wakeNow(int cooldown) {
        dataManager.set(REST, 0);
        dataManager.set(TRANS, 0);
        transTick = 0;
        sleepCooldown = cooldown;
    }

    /** Wake nearby sleepers (roar). */
    public void wakeUpOthers(double radius) {
        for (EntityDawnCreature o : world.getEntitiesWithinAABB(EntityDawnCreature.class, getEntityBoundingBox().grow(radius))) {
            if (o != this) o.wakeFromSleep();
        }
    }

    public void wakeFromSleep() {
        if (!world.isRemote && getRestState() == 2 && getTrans() == 0) {
            startTrans(3);
            sleepCooldown = 100;
        }
    }

    private boolean canSleepAtNight() { return !isTamed() || !isFollowing(); }

    private void updateRest() {
        if (sleepCooldown > 0) sleepCooldown--;
        if (noSleepTicks > 0) noSleepTicks--;
        int trans = getTrans();
        if (trans != 0) {
            transTick++;
            if (transTick >= TRANS_LEN[trans]) endTrans(trans);
            return;
        }
        int rest = getRestState();
        long t = world.getWorldTime() % 24000L;
        boolean night = t >= 13500L && t < 23000L;
        boolean calm = getAttackTarget() == null && onGround && !isInWater() && !isBeingRidden();
        boolean sitCommand = isTamed() && isSitting();

        int desired = 0;
        if (!calm) desired = 0;
        else if (sitCommand) desired = (rest == 2 && !night) ? 1 : Math.max(1, rest);
        else if (night && canSleepAtNight() && noSleepTicks <= 0) desired = 2;

        boolean standNow = !sitCommand && noSleepTicks > 0 && rest != 0 && calm;
        if (!standNow && (sleepCooldown > 0 || getAction() != null)) return;
        if (desired > rest) {
            if (rest == 0) {
                // wild/wandering creatures lie down at a random moment of the night; sit commands act at once
                if (sitCommand || rand.nextInt(200) == 0) startTrans(1);   // down: sit first
            } else {
                startTrans(2);                                             // rest -> fall_asleep -> sleep
            }
        } else if (desired < rest) {
            startTrans(rest == 2 ? 3 : 4);                                 // sleep -> wake_up -> rest -> up
        }
    }

    @Override
    public void applyEntityCollision(Entity e) {
        super.applyEntityCollision(e);
        if (!world.isRemote && e.getClass() != getClass() && getRestState() == 2 && getTrans() == 0 && sleepCooldown <= 0) {
            wakeFromSleep();
        }
    }

    // ------------------------------------------------------------ tick

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        float s = 0.3F + 0.7F * getGrowthProgress();
        if (Math.abs(s - lastScale) > 0.01F) {
            lastScale = s;
            setSize(getBaseWidth() * s, getBaseHeight() * s);
        }

        Action a = getAction();
        if (a != null) {
            if (actionTick < a.length) actionTick++;
            if (!world.isRemote) {
                onActionTick(a, actionTick);
                if (actionTick >= a.length) {
                    dataManager.set(ACTION, 0);
                    actionTick = 0;
                }
            }
        }

        int trans = getTrans();
        if (trans != 0) {
            if (world.isRemote) { if (transTick < TRANS_LEN[trans]) transTick++; }
            if (trans == 1 && transTick == 15 && !world.isRemote) DawnNetwork.shake(world, posX, posY, posZ, 0.4F, 14, 20.0D);
            if (trans == 3 && transTick == 20 && !world.isRemote) playDawn("sniff", 1.0F, 0.65F);
        }

        if (!world.isRemote) {
            if (ticksExisted == 1 || ticksExisted % 20 == 0) {
                int age = getAge();
                if (age < getAdultAgeTicks() && ticksExisted > 1) setAge(Math.min(getAdultAgeTicks(), age + 20));
                dataManager.set(HUNGER, Math.max(0F, getHunger() - 0.04F));   // empties in about 50 minutes
                updateGrowthStats();
                // slow natural regeneration (0.5 HP/s) while reasonably fed
                if (ticksExisted % 40 == 0 && getHealth() < getMaxHealth() && getHunger() >= getMaxHunger() * 0.5F) heal(1.0F);
            }
            if (breedCooldown > 0) breedCooldown--;
            tickControlled = getControllingPassenger() != null ? tickControlled + 1 : 0;
            if (energyBlock > 0) energyBlock--;
            else if (getEnergy() < getMaxEnergy()) dataManager.set(ENERGY, Math.min(getMaxEnergy(), getEnergy() + 0.5F));
            updateRest();
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (!world.isRemote && isResting() && amount > 0) wakeNow(90 + rand.nextInt(30));
        return super.attackEntityFrom(src, amount);
    }

    @Override
    protected boolean isMovementBlocked() {
        return super.isMovementBlocked() || isLocked() || isResting();
    }

    private boolean frozen() { return isLocked() || isResting() || isSitting(); }

    @Override
    public boolean canBePushed() { return false; }

    // ------------------------------------------------------------ riding (Dawn Era BaseRideableAnimal)

    @Override
    @Nullable
    public Entity getControllingPassenger() {
        List<Entity> l = getPassengers();
        return l.isEmpty() ? null : l.get(0);
    }

    /** Server-driven steering (see travel): the client never simulates this mount itself. */
    @Override
    public boolean canPassengerSteer() {
        return !world.isRemote && getControllingPassenger() instanceof EntityPlayer;
    }

    @Override
    public double getMountedYOffset() { return height * (isInWater() ? 0.5D : 0.765D); }

    private static float lerpAngle(float t, float from, float to) { return from + t * MathHelper.wrapDegrees(to - from); }

    @Override
    public void travel(float strafe, float vertical, float forward) {
        Entity rider = getControllingPassenger();
        if (isBeingRidden() && rider instanceof EntityPlayer && isSaddled()) {
            if (!world.isRemote) {
                // The SERVER drives the mount: the rider's keys reach it in CPacketInput (moveForward / moveStrafing),
                // and the client just follows the position packets. This avoids all client/server steering mismatches.
                EntityPlayer r = (EntityPlayer) rider;
                float f = r.moveForward < 0.0F ? 0.0F : 1.0F;
                strafe = r.moveStrafing * 0.35F;
                forward = r.moveForward * 0.8F * f;
                if (isLocked() || isResting()) { strafe = 0.0F; forward = 0.0F; }
                if (!isResting() && (r.moveForward != 0.0F || r.moveStrafing != 0.0F)) {
                    // smooth turning towards where the rider looks (only while the rider is moving)
                    renderYawOffset = rotationYawHead = lerpAngle(0.15F, prevRotationYaw, r.rotationYaw);
                    prevRotationYaw = rotationYawHead;
                    setRotation(lerpAngle(0.1F, rotationYaw, r.rotationYaw),
                            rotationPitch + 0.1F * (MathHelper.clamp(r.rotationPitch, -40.0F, 40.0F) - rotationPitch));
                }
                if (isInWater()) {
                    swimTravel(strafe, vertical, forward * (r.isSprinting() ? 1.5F : 1.0F));
                    updateLimbs();
                } else {
                    float speed = (float) getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue();
                    setAIMoveSpeed(speed * (r.isSprinting() ? RIDING_SPRINT_SPEED : RIDING_SPEED));
                    super.travel(strafe, vertical, forward);
                }
            } else {
                motionX = 0.0D; motionY = 0.0D; motionZ = 0.0D;
                updateLimbs();
            }
            return;
        }
        boolean frozen = frozen();
        if (frozen) { strafe = 0.0F; forward = 0.0F; }
        if (isInWater()) {
            // AI move values are tiny: just use the direction
            float fw = forward > 0.01F ? 1.0F : (forward < -0.01F ? -1.0F : 0.0F);
            swimTravel(0.0F, vertical, fw);
            updateLimbs();
            return;
        }
        super.travel(strafe, vertical, forward);
        if (frozen) { motionX = 0.0D; motionZ = 0.0D; }
    }

    private void updateLimbs() {
        prevLimbSwingAmount = limbSwingAmount;
        double dx = posX - prevPosX, dz = posZ - prevPosZ;
        float f = MathHelper.sqrt(dx * dx + dz * dz) * 4.0F;
        if (f > 1.0F) f = 1.0F;
        limbSwingAmount += (f - limbSwingAmount) * 0.4F;
        limbSwing += limbSwingAmount;
    }

    /** Swimming: moves along its heading and floats with the middle of the body at the water surface. */
    private void swimTravel(float strafe, float vertical, float forward) {
        moveRelative(strafe, vertical, forward, SWIM_ACCELERATION);
        move(MoverType.SELF, motionX, motionY, motionZ);
        motionX *= 0.8D;
        motionY *= 0.8D;
        motionZ *= 0.8D;
        if (world.getBlockState(new BlockPos(posX, posY + height * 0.5D, posZ)).getMaterial() == Material.WATER) motionY += 0.04D;
        else if (world.getBlockState(new BlockPos(posX, posY + height * 0.3D, posZ)).getMaterial() != Material.WATER) motionY -= 0.02D;
        if (collidedHorizontally && forward > 0.0F) motionY = 0.3D;   // climb out onto the shore
    }

    // ------------------------------------------------------------ interaction / taming / breeding

    public boolean canBreed() { return isTamed() && isAdult() && breedCooldown <= 0 && !isInLove(); }

    protected void tameBy(EntityPlayer player) {
        setTamedBy(player);
        setFollowing(true);
        navigator.clearPath();
        setAttackTarget(null);
        world.setEntityState(this, (byte) 7);
    }

    /** Called by the mating AI when the female reaches an in-love male. */
    public void mateWith(EntityDawnCreature partner) {
        layEgg();
        resetInLove();
        partner.resetInLove();
        breedCooldown = 12000;
        partner.breedCooldown = 12000;
        world.setEntityState(this, (byte) 18);
        if (world.getGameRules().getBoolean("doMobLoot")) {
            world.spawnEntity(new EntityXPOrb(world, posX, posY, posZ, rand.nextInt(7) + 1));
        }
    }

    public void togglePrivateMount(EntityPlayer p) {
        setPrivateMount(!isPrivateMount());
        p.sendStatusMessage(new TextComponentTranslation(isPrivateMount() ? "msg.dawnera.order.private" : "msg.dawnera.order.public", getDisplayName()), true);
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack s = player.getHeldItem(hand);
        boolean creative = player.capabilities.isCreativeMode;

        // Creative shortcut for testing: right-click with an empty hand tames instantly
        if (!isTamed() && creative && s.isEmpty() && hand == EnumHand.MAIN_HAND) {
            if (!world.isRemote) tameBy(player);
            return true;
        }

        if (s.getItem() instanceof ItemFood && ((ItemFood) s.getItem()).isWolfsFavoriteMeat()) {
            ItemFood food = (ItemFood) s.getItem();
            if (!isTamed()) {
                // Survival: wild adults cannot be tamed. Hatchlings can be raised by feeding them.
                if (!(creative || isChild())) return false;
                if (getHunger() >= getMaxHunger() - 1F) return false;
                if (!world.isRemote) {
                    feed(player, s, food);
                    tameBy(player);
                }
                return true;
            }
            if (getHunger() < getMaxHunger() - 1F) {
                if (!world.isRemote) feed(player, s, food);
                return true;
            }
            if (isOwner(player) && canBreed() && getHunger() >= getMaxHunger() * 0.8F) {
                if (!world.isRemote) {
                    if (!creative) s.shrink(1);
                    setInLove(player);
                }
                return true;
            }
            return false;
        }

        if (isTamed() && isOwner(player)) {
            if (s.isEmpty() && hand == EnumHand.MAIN_HAND && player.isSneaking()) {
                if (!world.isRemote) player.openGui(DawnEra.INSTANCE, 0, world, getEntityId(), 0, 0);
                return true;
            }
            if (isAdult()) {
                if (s.getItem() == DawnItems.SADDLE && !isSaddled()) {
                    if (!world.isRemote) {
                        setSaddled(true);
                        playSound(SoundEvents.ENTITY_HORSE_SADDLE, 0.5F, 1.0F);
                        if (!creative) s.shrink(1);
                    }
                    return true;
                }
                if (s.getItem() == DawnItems.ARMOR && !isArmored()) {
                    if (!world.isRemote) {
                        setArmored(true);
                        playSound(SoundEvents.ENTITY_HORSE_ARMOR, 0.5F, 1.0F);
                        if (!creative) s.shrink(1);
                    }
                    return true;
                }
            }
        }

        // mount: saddled adult; the owner always, anyone else when it is set to "public"
        if (isTamed() && isAdult() && isSaddled() && !isBeingRidden() && s.isEmpty() && hand == EnumHand.MAIN_HAND
                && !player.isSneaking() && (isOwner(player) || !isPrivateMount())) {
            if (!world.isRemote) {
                aiSit.setSitting(false);   // mounting always stands it up
                setSitting(false);
                requestStand();
                player.startRiding(this);
            }
            return true;
        }
        return false;
    }

    private void feed(EntityPlayer player, ItemStack s, ItemFood food) {
        dataManager.set(HUNGER, Math.min(getMaxHunger(), getHunger() + food.getHealAmount(s) * 4F));
        if (!player.capabilities.isCreativeMode) s.shrink(1);
        playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0F, 0.7F);
        if (getEatAction() != null) startAction(getEatAction());
    }

    // ------------------------------------------------------------ combat helpers

    protected boolean isFriendly(Entity e, @Nullable EntityPlayer rider) {
        if (e == this || e.getClass() == this.getClass() || isPassenger(e) || e == rider) return true;
        if (e instanceof EntityTameable) {
            EntityTameable pet = (EntityTameable) e;
            if (rider != null && pet.isOwner(rider)) return true;
            if (getOwner() != null && pet.isOwner(getOwner())) return true;
        }
        return e instanceof EntityPlayer && isTamed() && isOwner((EntityPlayer) e);
    }

    @Nullable
    protected EntityPlayer getRiderPlayer() {
        Entity r = getControllingPassenger();
        return r instanceof EntityPlayer ? (EntityPlayer) r : null;
    }

    protected void damage(EntityLivingBase t, float mult) {
        float grow = 0.15F + 0.85F * getGrowthProgress();
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * mult * DAMAGE_SCALE * grow;
        t.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
        particles(EnumParticleTypes.DAMAGE_INDICATOR, t.posX, t.posY + t.height * 0.5D, t.posZ, 6, 0.3D, 0.3D, 0.3D, 0.1D);
    }

    protected void slow(EntityLivingBase t, int ticks, int amp) {
        t.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, ticks, amp, true, false));
    }

    protected List<EntityLivingBase> frontEntities(double reach) {
        EntityPlayer rider = getRiderPlayer();
        Vec3d fwd = forward();
        List<EntityLivingBase> all = world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(reach, 1.5D, reach));
        all.removeIf(e -> {
            if (isFriendly(e, rider)) return true;
            double dx = e.posX - posX, dz = e.posZ - posZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            return len > 0.001D && (dx / len * fwd.x + dz / len * fwd.z) < 0.3D;
        });
        return all;
    }

    /** Forward direction (horizontal) of the body. */
    protected Vec3d forward() {
        float yaw = renderYawOffset * 0.017453292F;
        return new Vec3d(-MathHelper.sin(yaw), 0.0D, MathHelper.cos(yaw));
    }

    /** Approximate mouth position. */
    protected Vec3d headPos() {
        Vec3d f = forward();
        double d = width * 0.75D;
        return new Vec3d(posX + f.x * d, posY + height * 0.8D, posZ + f.z * d);
    }

    protected void particles(EnumParticleTypes t, double x, double y, double z, int count, double dx, double dy, double dz, double speed, int... args) {
        if (world instanceof WorldServer) ((WorldServer) world).spawnParticle(t, x, y, z, count, dx, dy, dz, speed, args);
    }

    // ------------------------------------------------------------ sounds / drops

    @Nullable
    protected SoundEvent sound(String name) {
        return DawnSounds.get("entity." + getSpeciesId() + "." + name);
    }

    protected void playDawn(String name, float volume, float pitch) {
        SoundEvent s = sound(name);
        if (s != null) playSound(s, volume, getSoundPitch() * pitch);
    }

    @Override protected SoundEvent getAmbientSound() {
        if (isLocked()) return null;
        return sound(isDawnSleeping() ? "sleep" : "idle");
    }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return sound("hurt"); }
    @Override protected SoundEvent getDeathSound() { return sound("death"); }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        int n = 2 + rand.nextInt(3 + looting);
        for (int i = 0; i < n; i++) dropItem(Items.BONE, 1);
        if (recentlyHit) for (int i = 0; i < 2 + rand.nextInt(3); i++) dropItem(Items.BEEF, 1);
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) {
            if (isSaddled()) entityDropItem(new ItemStack(DawnItems.SADDLE), 0.5F);
            if (isArmored()) entityDropItem(new ItemStack(DawnItems.ARMOR), 0.5F);
        }
        super.onDeath(cause);
    }

    /** Killing something by itself restores health. */
    @Override
    public void onKillEntity(EntityLivingBase victim) {
        super.onKillEntity(victim);
        if (!world.isRemote && isEntityAlive()) {
            heal(getKillHeal());
            particles(EnumParticleTypes.HEART, posX, posY + height * 0.8D, posZ, 6, 0.8D, 0.5D, 0.8D, 0.02D);
        }
    }

    @Override
    public boolean canBreatheUnderwater() { return true; }

    @Override
    public EntityAgeable createChild(EntityAgeable other) { return null; }
}
