package dawnera;

import dawnera.entity.EntityDawnCreature;
import net.minecraft.entity.Entity;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

public class DawnEvents {
    /** While riding, the mouse buttons belong to the mount (attack / roar), so normal melee and block breaking are off. */
    @SubscribeEvent
    public void onAttack(AttackEntityEvent e) {
        Entity mount = e.getEntityPlayer().getRidingEntity();
        if (mount instanceof EntityDawnCreature) e.setCanceled(true);
    }

    @SubscribeEvent
    public void onLeftClickBlock(PlayerInteractEvent.LeftClickBlock e) {
        if (e.getEntityPlayer().getRidingEntity() instanceof EntityDawnCreature) e.setCanceled(true);
    }
}
