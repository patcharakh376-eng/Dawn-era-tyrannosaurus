package dawnera;

public class CommonProxy {
    public void preInit() {}
}
