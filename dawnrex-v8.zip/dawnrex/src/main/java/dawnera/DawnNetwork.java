package dawnera;

import net.minecraft.world.World;
import net.minecraftforge.fml.common.network.NetworkRegistry;
import net.minecraftforge.fml.common.network.simpleimpl.SimpleNetworkWrapper;
import net.minecraftforge.fml.relauncher.Side;

public class DawnNetwork {
    public static final SimpleNetworkWrapper NET = NetworkRegistry.INSTANCE.newSimpleChannel(DawnEra.MODID);

    public static void init() {
        NET.registerMessage(MessageShake.Handler.class, MessageShake.class, 0, Side.CLIENT);
    }

    /** Server side: shake the camera of every player within range. */
    public static void shake(World w, double x, double y, double z, float intensity, int duration, double range) {
        if (w.isRemote) return;
        NET.sendToAllAround(new MessageShake(x, y, z, intensity, duration, (float) range),
                new NetworkRegistry.TargetPoint(w.provider.getDimension(), x, y, z, range));
    }
}
