package dawnera.entity;

import dawnera.DawnEra;
import dawnera.DawnItems;
import dawnera.DawnSounds;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttribute;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.item.EntityXPOrb;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemFood;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Shared core for every Dawn Era creature on 1.12.2: growth, gender, hunger, sleep/sit postures, taming,
 * breeding (egg), saddle + armor, riding, and a small action state machine (replacement for AstemirLib ActionState).
 */
public abstract class EntityDawnCreature extends EntityTameable {
    /** One playable action (attack, roar, ...). length is in ticks. */
    public static class Action {
        public final String id, anim;
        public final int length;
        public Action(String id, String anim, int length) { this.id = id; this.anim = anim; this.length = length; }
    }

    private static final DataParameter<Integer> ACTION = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> SADDLED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> ARMORED = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> MALE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> SLEEPING = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Integer> AGE = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> FOLLOW = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Float> HUNGER = EntityDataManager.createKey(EntityDawnCreature.class, DataSerializers.FLOAT);
    private static final UUID ARMOR_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a12");
    private static final UUID ARMOR_HP_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a13");
    private static final UUID ARMOR_TOUGH_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a14");

    /** Wearing the armor item: +20 armor, +30 max health, +5 armor toughness. */
    protected static final double ARMOR_BONUS = 20.0D;
    protected static final double ARMOR_HP_BONUS = 30.0D;
    protected static final double ARMOR_TOUGHNESS_BONUS = 5.0D;
    /** Multiplier for all attack damage (Dawn Era values are very high). */
    protected static final float DAMAGE_SCALE = 1.0F;

    public int actionTick;
    public int breedCooldown;
    private int postureLock;
    private int serverPosture;
    private float lastScale = -1F;

    // client-side animation state (plain data, read only by the renderer)
    public String animCur = "";
    public String animPrev = "";
    public float animCurTime, animPrevTime, animChangeAt;
    /** 0 standing, 1 sleeping, 2 sitting; plus the transition animation currently playing. */
    public int posture;
    private int lastPosture;
    public int postureTransTick = 1000;
    public String postureTransAnim = "";

    protected EntityDawnCreature(World world) {
        super(world);
        this.stepHeight = 2.0F;
    }

    // ------------------------------------------------------------ species data (implemented by each creature)

    public abstract String getSpeciesId();
    protected abstract Action[] getActions();
    protected abstract float getBaseWidth();
    protected abstract float getBaseHeight();
    /** Ticks until fully grown. */
    protected abstract int getAdultAgeTicks();
    protected abstract float getMaxHunger();
    protected abstract float getAdultMaxHealth();
    public abstract Action pickAttack();
    /** Server-side: called once per tick while an action plays. t = ticks since the action started. */
    protected abstract void onActionTick(Action a, int t);
    /** Female lays her egg (placed block / item). */
    protected abstract void layEgg();
    @Nullable protected Action getEatAction() { return null; }

    // ------------------------------------------------------------ data

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(ACTION, 0);
        dataManager.register(SADDLED, false);
        dataManager.register(ARMORED, false);
        dataManager.register(MALE, true);
        dataManager.register(SLEEPING, false);
        dataManager.register(AGE, Integer.MAX_VALUE / 2);
        dataManager.register(HUNGER, 100F);
        dataManager.register(FOLLOW, true);
    }

    /** Call at the end of each species constructor. */
    protected void initDefaults() {
        setSize(getBaseWidth(), getBaseHeight());
        dataManager.set(MALE, rand.nextBoolean());
        dataManager.set(HUNGER, getMaxHunger());
        setHealth(getMaxHealth());
    }

    public boolean isMale() { return dataManager.get(MALE); }
    public int getAge() { return dataManager.get(AGE); }
    public void setAge(int ticks) { dataManager.set(AGE, ticks); }
    public boolean isAdult() { return getAge() >= getAdultAgeTicks(); }
    @Override public boolean isChild() { return !isAdult(); }
    public float getGrowthProgress() { return Math.min(1.0F, getAge() / (float) getAdultAgeTicks()); }
    public float getHunger() { return dataManager.get(HUNGER); }
    public float getMaxHungerPublic() { return getMaxHunger(); }
    public boolean isHungry() { return getHunger() < getMaxHunger() * 0.6F; }
    public boolean isDawnSleeping() { return dataManager.get(SLEEPING); }
    public void setDawnSleeping(boolean v) { dataManager.set(SLEEPING, v); }
    public boolean isFollowing() { return dataManager.get(FOLLOW); }
    public void setFollowing(boolean v) { dataManager.set(FOLLOW, v); }
    public void toggleSit() { aiSit.setSitting(!isSitting()); isJumping = false; navigator.clearPath(); setAttackTarget(null); }
    public boolean isSaddled() { return dataManager.get(SADDLED); }
    public boolean isArmored() { return dataManager.get(ARMORED); }
    public void setSaddled(boolean v) { dataManager.set(SADDLED, v); }

    public void setArmored(boolean v) { setArmored(v, true); }

    public void setArmored(boolean v, boolean heal) {
        dataManager.set(ARMORED, v);
        if (world.isRemote) return;
        modifier(SharedMonsterAttributes.ARMOR, ARMOR_UUID, "dawnera armor", ARMOR_BONUS, v);
        modifier(SharedMonsterAttributes.ARMOR_TOUGHNESS, ARMOR_TOUGH_UUID, "dawnera armor toughness", ARMOR_TOUGHNESS_BONUS, v);
        modifier(SharedMonsterAttributes.MAX_HEALTH, ARMOR_HP_UUID, "dawnera armor health", ARMOR_HP_BONUS, v);
        if (v && heal) setHealth(getHealth() + (float) ARMOR_HP_BONUS);
        else if (getHealth() > getMaxHealth()) setHealth(getMaxHealth());
    }

    private void modifier(IAttribute attr, UUID id, String name, double value, boolean on) {
        IAttributeInstance inst = getEntityAttribute(attr);
        if (inst.getModifier(id) != null) inst.removeModifier(id);
        if (on) inst.applyModifier(new AttributeModifier(id, name, value, 0));
    }

    /** Baby is weak (10% health), adult is full strength. */
    private void updateGrowthStats() {
        double target = getAdultMaxHealth() * (0.1D + 0.9D * getGrowthProgress());
        IAttributeInstance hp = getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH);
        if (Math.abs(hp.getBaseValue() - target) > 0.5D) {
            float ratio = getHealth() / getMaxHealth();
            hp.setBaseValue(target);
            setHealth(Math.min(getMaxHealth(), ratio * getMaxHealth()));
        }
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setInteger("DawnAge", getAge());
        c.setFloat("DawnHunger", getHunger());
        c.setBoolean("DawnMale", isMale());
        c.setBoolean("DawnSaddled", isSaddled());
        c.setBoolean("DawnArmored", isArmored());
        c.setBoolean("DawnFollow", isFollowing());
        c.setInteger("DawnBreedCooldown", breedCooldown);
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        if (c.hasKey("DawnAge")) setAge(c.getInteger("DawnAge"));
        if (c.hasKey("DawnHunger")) dataManager.set(HUNGER, c.getFloat("DawnHunger"));
        if (c.hasKey("DawnMale")) dataManager.set(MALE, c.getBoolean("DawnMale"));
        setSaddled(c.getBoolean("DawnSaddled"));
        setArmored(c.getBoolean("DawnArmored"), false);
        if (c.hasKey("DawnFollow")) setFollowing(c.getBoolean("DawnFollow"));
        breedCooldown = c.getInteger("DawnBreedCooldown");
    }

    // ------------------------------------------------------------ actions

    public Action getAction() {
        int i = dataManager.get(ACTION);
        Action[] all = getActions();
        return i > 0 && i <= all.length ? all[i - 1] : null;
    }

    public boolean isLocked() { return getAction() != null; }

    public void startAction(Action a) { startAction(a, false); }

    public void startAction(Action a, boolean force) {
        if (world.isRemote || a == null) return;
        if (!force && getAction() != null) return;
        Action[] all = getActions();
        for (int i = 0; i < all.length; i++) {
            if (all[i] == a) {
                dataManager.set(ACTION, i + 1);
                actionTick = 0;
                return;
            }
        }
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        super.notifyDataManagerChange(key);
        if (ACTION.equals(key)) actionTick = 0;
    }

    public void riderAttack() {
        if (!isDawnSleeping() && getAction() == null && isAdult()) startAction(pickAttack());
    }

    // ------------------------------------------------------------ tick

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();

        float s = 0.3F + 0.7F * getGrowthProgress();
        if (Math.abs(s - lastScale) > 0.01F) {
            lastScale = s;
            setSize(getBaseWidth() * s, getBaseHeight() * s);
        }

        Action a = getAction();
        if (a != null) {
            if (actionTick < a.length) actionTick++;
            if (!world.isRemote) {
                onActionTick(a, actionTick);
                if (actionTick >= a.length) {
                    dataManager.set(ACTION, 0);
                    actionTick = 0;
                }
            }
        }

        int p = isDawnSleeping() ? 1 : (isSitting() ? 2 : 0);
        if (!world.isRemote) {
            if (ticksExisted == 1 || ticksExisted % 20 == 0) {
                int age = getAge();
                if (age < getAdultAgeTicks() && ticksExisted > 1) setAge(Math.min(getAdultAgeTicks(), age + 20));
                dataManager.set(HUNGER, Math.max(0F, getHunger() - 0.25F));
                updateGrowthStats();
            }
            if (breedCooldown > 0) breedCooldown--;
            if (postureLock > 0) postureLock--;
            if (p != serverPosture) {
                // lock movement while the lie-down / sit / get-up animation plays
                postureLock = p == 1 ? 60 : (p == 2 ? 31 : (serverPosture == 1 ? 75 : 45));
                serverPosture = p;
            }
            updateSleep();
        } else {
            if (p != lastPosture) {
                postureTransAnim = p == 1 ? "animation.model.fall_asleep" : (p == 2 ? "animation.model.down"
                        : (lastPosture == 1 ? "animation.model.wake_up" : "animation.model.up"));
                lastPosture = p;
                postureTransTick = 0;
            }
            posture = p;
            if (postureTransTick < 1000) postureTransTick++;
        }
    }

    private void updateSleep() {
        long t = world.getWorldTime() % 24000L;
        boolean night = t >= 13500L && t < 23000L;
        boolean calm = getAttackTarget() == null && onGround && !isInWater() && !isBeingRidden() && getAction() == null;
        if (!isDawnSleeping()) {
            if (night && calm && !isSitting() && rand.nextInt(300) == 0) setDawnSleeping(true);
        } else if (!night || !calm) {
            setDawnSleeping(false);
        }
    }

    @Override
    public boolean attackEntityFrom(DamageSource src, float amount) {
        if (isDawnSleeping() && !world.isRemote) setDawnSleeping(false);
        return super.attackEntityFrom(src, amount);
    }

    @Override
    protected boolean isMovementBlocked() {
        return super.isMovementBlocked() || isDawnSleeping() || isLocked() || postureLock > 0;
    }

    private boolean frozen() { return isLocked() || isDawnSleeping() || postureLock > 0 || isSitting(); }

    @Override
    public boolean canBePushed() { return false; }

    // ------------------------------------------------------------ riding

    @Override
    @Nullable
    public Entity getControllingPassenger() {
        List<Entity> l = getPassengers();
        return l.isEmpty() ? null : l.get(0);
    }

    @Override
    public double getMountedYOffset() { return height * 0.85D; }

    @Override
    public void travel(float strafe, float vertical, float forward) {
        Entity rider = getControllingPassenger();
        if (isBeingRidden() && rider instanceof EntityLivingBase && isSaddled()) {
            EntityLivingBase r = (EntityLivingBase) rider;
            rotationYaw = r.rotationYaw;
            prevRotationYaw = rotationYaw;
            rotationPitch = r.rotationPitch * 0.5F;
            setRotation(rotationYaw, rotationPitch);
            renderYawOffset = rotationYaw;
            rotationYawHead = renderYawOffset;
            strafe = r.moveStrafing * 0.5F;
            forward = r.moveForward;
            if (forward <= 0.0F) forward *= 0.25F;
            if (isLocked() || isDawnSleeping()) { strafe = 0F; forward = 0F; }
            if (canPassengerSteer()) {
                float speed = (float) getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).getAttributeValue();
                setAIMoveSpeed(speed * (r.isSprinting() ? 1.8F : 0.9F));
                super.travel(strafe, vertical, forward);
            } else {
                motionX = 0.0D; motionY = 0.0D; motionZ = 0.0D;
            }
            prevLimbSwingAmount = limbSwingAmount;
            double dx = posX - prevPosX, dz = posZ - prevPosZ;
            float f = MathHelper.sqrt(dx * dx + dz * dz) * 4.0F;
            if (f > 1.0F) f = 1.0F;
            limbSwingAmount += (f - limbSwingAmount) * 0.4F;
            limbSwing += limbSwingAmount;
            return;
        }
        boolean frozen = frozen();
        if (frozen) { strafe = 0.0F; forward = 0.0F; }
        super.travel(strafe, vertical, forward);
        if (frozen) { motionX = 0.0D; motionZ = 0.0D; }
    }

    // ------------------------------------------------------------ interaction / taming / breeding

    public boolean canBreed() { return isTamed() && isAdult() && breedCooldown <= 0 && !isInLove(); }

    protected void tameBy(EntityPlayer player) {
        setTamedBy(player);
        setFollowing(true);
        navigator.clearPath();
        setAttackTarget(null);
        world.setEntityState(this, (byte) 7);
    }

    /** Called by the mating AI when the female reaches an in-love male. */
    public void mateWith(EntityDawnCreature partner) {
        layEgg();
        resetInLove();
        partner.resetInLove();
        breedCooldown = 12000;
        partner.breedCooldown = 12000;
        world.setEntityState(this, (byte) 18);
        if (world.getGameRules().getBoolean("doMobLoot")) {
            world.spawnEntity(new EntityXPOrb(world, posX, posY, posZ, rand.nextInt(7) + 1));
        }
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack s = player.getHeldItem(hand);
        boolean creative = player.capabilities.isCreativeMode;

        // Creative shortcut for testing: right-click with an empty hand tames instantly
        if (!isTamed() && creative && s.isEmpty() && hand == EnumHand.MAIN_HAND) {
            if (!world.isRemote) tameBy(player);
            return true;
        }

        if (s.getItem() instanceof ItemFood && ((ItemFood) s.getItem()).isWolfsFavoriteMeat()) {
            ItemFood food = (ItemFood) s.getItem();
            if (!isTamed()) {
                // Survival: wild adults cannot be tamed. Hatchlings can be raised by feeding them.
                if (!(creative || isChild())) return false;
                if (getHunger() >= getMaxHunger() - 1F) return false;
                if (!world.isRemote) {
                    feed(player, s, food);
                    tameBy(player);
                }
                return true;
            }
            if (getHunger() < getMaxHunger() - 1F) {
                if (!world.isRemote) feed(player, s, food);
                return true;
            }
            if (isOwner(player) && canBreed() && getHunger() >= getMaxHunger() * 0.8F) {
                if (!world.isRemote) {
                    if (!creative) s.shrink(1);
                    setInLove(player);
                }
                return true;
            }
            return false;
        }

        if (isTamed() && isOwner(player)) {
            if (s.isEmpty() && hand == EnumHand.MAIN_HAND && player.isSneaking()) {
                if (!world.isRemote) player.openGui(DawnEra.INSTANCE, 0, world, getEntityId(), 0, 0);
                return true;
            }
            if (isAdult()) {
                if (s.getItem() == DawnItems.SADDLE && !isSaddled()) {
                    if (!world.isRemote) {
                        setSaddled(true);
                        playSound(SoundEvents.ENTITY_HORSE_SADDLE, 0.5F, 1.0F);
                        if (!creative) s.shrink(1);
                    }
                    return true;
                }
                if (s.getItem() == DawnItems.ARMOR && !isArmored()) {
                    if (!world.isRemote) {
                        setArmored(true);
                        playSound(SoundEvents.ENTITY_HORSE_ARMOR, 0.5F, 1.0F);
                        if (!creative) s.shrink(1);
                    }
                    return true;
                }
                if (s.isEmpty() && hand == EnumHand.MAIN_HAND && isSaddled() && !isBeingRidden()) {
                    if (!world.isRemote) player.startRiding(this);
                    return true;
                }
            }
        }
        return false;
    }

    private void feed(EntityPlayer player, ItemStack s, ItemFood food) {
        dataManager.set(HUNGER, Math.min(getMaxHunger(), getHunger() + food.getHealAmount(s) * 4F));
        if (!player.capabilities.isCreativeMode) s.shrink(1);
        playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0F, 0.7F);
        if (getEatAction() != null) startAction(getEatAction());
    }

    // ------------------------------------------------------------ combat helpers

    protected boolean isFriendly(Entity e, @Nullable EntityPlayer rider) {
        if (e == this || e.getClass() == this.getClass() || isPassenger(e) || e == rider) return true;
        if (e instanceof EntityTameable) {
            EntityTameable pet = (EntityTameable) e;
            if (rider != null && pet.isOwner(rider)) return true;
            if (getOwner() != null && pet.isOwner(getOwner())) return true;
        }
        return e instanceof EntityPlayer && isTamed() && isOwner((EntityPlayer) e);
    }

    @Nullable
    protected EntityPlayer getRiderPlayer() {
        Entity r = getControllingPassenger();
        return r instanceof EntityPlayer ? (EntityPlayer) r : null;
    }

    protected void damage(EntityLivingBase t, float mult) {
        float grow = 0.15F + 0.85F * getGrowthProgress();
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * mult * DAMAGE_SCALE * grow;
        t.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
        particles(EnumParticleTypes.DAMAGE_INDICATOR, t.posX, t.posY + t.height * 0.5D, t.posZ, 6, 0.3D, 0.3D, 0.3D, 0.1D);
    }

    protected void slow(EntityLivingBase t, int ticks, int amp) {
        t.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, ticks, amp, true, false));
    }

    protected List<EntityLivingBase> frontEntities(double reach) {
        EntityPlayer rider = getRiderPlayer();
        float yaw = renderYawOffset * 0.017453292F;
        Vec3d fwd = new Vec3d(-MathHelper.sin(yaw), 0.0D, MathHelper.cos(yaw));
        List<EntityLivingBase> all = world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(reach, 1.5D, reach));
        all.removeIf(e -> {
            if (isFriendly(e, rider)) return true;
            double dx = e.posX - posX, dz = e.posZ - posZ;
            double len = Math.sqrt(dx * dx + dz * dz);
            return len > 0.001D && (dx / len * fwd.x + dz / len * fwd.z) < 0.3D;
        });
        return all;
    }

    /** Forward direction (horizontal) of the body. */
    protected Vec3d forward() {
        float yaw = renderYawOffset * 0.017453292F;
        return new Vec3d(-MathHelper.sin(yaw), 0.0D, MathHelper.cos(yaw));
    }

    /** Approximate mouth position. */
    protected Vec3d headPos() {
        Vec3d f = forward();
        double d = width * 0.75D;
        return new Vec3d(posX + f.x * d, posY + height * 0.8D, posZ + f.z * d);
    }

    protected void particles(EnumParticleTypes t, double x, double y, double z, int count, double dx, double dy, double dz, double speed, int... args) {
        if (world instanceof WorldServer) ((WorldServer) world).spawnParticle(t, x, y, z, count, dx, dy, dz, speed, args);
    }

    // ------------------------------------------------------------ sounds / drops

    @Nullable
    protected SoundEvent sound(String name) {
        return DawnSounds.get("entity." + getSpeciesId() + "." + name);
    }

    @Override protected SoundEvent getAmbientSound() {
        if (isLocked()) return null;
        return sound(isDawnSleeping() ? "sleep" : "idle");
    }
    @Override protected SoundEvent getHurtSound(DamageSource src) { return sound("hurt"); }
    @Override protected SoundEvent getDeathSound() { return sound("death"); }

    @Override
    protected void dropFewItems(boolean recentlyHit, int looting) {
        int n = 2 + rand.nextInt(3 + looting);
        for (int i = 0; i < n; i++) dropItem(Items.BONE, 1);
        if (recentlyHit) for (int i = 0; i < 2 + rand.nextInt(3); i++) dropItem(Items.BEEF, 1);
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) {
            if (isSaddled()) entityDropItem(new ItemStack(DawnItems.SADDLE), 0.5F);
            if (isArmored()) entityDropItem(new ItemStack(DawnItems.ARMOR), 0.5F);
        }
        super.onDeath(cause);
    }

    @Override
    public EntityAgeable createChild(EntityAgeable other) { return null; }
}
