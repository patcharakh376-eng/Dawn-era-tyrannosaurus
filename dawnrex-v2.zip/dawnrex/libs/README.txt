fossilsarcheology-8.0.6.jar is already here (classes only, trimmed from your jar - keep the repo PRIVATE).
Still needed: upload llibrary-1.7.20.jar (llibrary for 1.12.2, from CurseForge) into this folder.
