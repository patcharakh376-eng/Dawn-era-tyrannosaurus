# Dawn Rex (addon for Fossils and Archeology Revival, 1.12.2)

Replaces the Fossils Tyrannosaurus with a Dawn Era style Tyrannosaurus. Private use only:
The Dawn Era is All-Rights-Reserved, so do not redistribute this build or its assets.

## Build
1. Set up ForgeGradle 2.3 (JDK 8). Put the Fossils jar (renamed `fossilsarcheology-8.0.6.jar`) and llibrary in `libs/`.
2. `gradlew setupDecompWorkspace` then `gradlew build`. The jar appears in `build/libs`.
3. Put the jar next to Fossils and llibrary in `mods/`.

## What is replaced
- `EntityDawnTyrannosaurus` (subclass of the Fossils T-Rex, so eggs/DNA/taming/dinopedia still work).
  Old AI list replaced; new melee AI; Dawn actions: attack1, attack2, ram, ground slam, roar, sniff, eat.
- `ReplaceHandler` converts every old T-Rex (natural spawn, egg hatch, existing saves) into the new one, keeping NBT.
- Model + animations: Dawn geo.json / animation.json read at runtime (no GeckoLib/AstemirLib needed), baby model included.
- Sounds: all Dawn T-Rex sounds registered (`sounds.json` + `SoundEvent`s).
- Saddle + armor items, extra-texture render passes, saddle is required for riding (Fossils whip). Armor = +15 armor.
- Recipes (1.12.2): saddle = bone/gold/diamond/leather, armor = gold+diamond (netherite and triceratops horn do not exist in 1.12.2).

## Not ported / simplified (check these first when testing)
- Not compiled or run here (no Forge 1.12.2 toolchain in the sandbox): expect to fix a few compile errors.
- Dawn systems not ported: screen shake, tree breaking, sleep schedule (Fossils sleep is used, with the fall_asleep/wake_up/sleep animations), rest/down/up, roar particles, FRACTURE effect (replaced by Slowness), spawn config.
- Tunables: `ADULT_SCALE` / `BABY_SCALE` in RenderDawnTyrannosaurus, `DAMAGE_SCALE` / `ARMOR_BONUS` in the entity.
- Rider keys use the Fossils hooks (`playerAttack`, `playerRoar`).
