package dawnrex.client;

import dawnrex.DawnRex;
import dawnrex.anim.DawnAnimations;
import dawnrex.entity.DawnAction;
import dawnrex.entity.EntityDawnTyrannosaurus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class RenderDawnTyrannosaurus extends RenderLiving<EntityDawnTyrannosaurus> {
    private static ResourceLocation tex(String n) { return new ResourceLocation(DawnRex.MODID, "textures/entity/tyrannosaurus/" + n + ".png"); }
    private static final ResourceLocation MALE = tex("male"), FEMALE = tex("female"), BABY = tex("baby"),
            SADDLE = tex("saddle_0"), ARMOR = tex("armor_0");
    /** Tunable: size of the Dawn model relative to the Fossils hitbox scale (getAgeScale / 2.8). */
    private static final float ADULT_SCALE = 0.78F / 2.8F;
    private static final float BABY_SCALE = 1.0F;
    private static final float BLEND_TICKS = 3.0F; // 0.15s, same as Dawn Era

    private DawnGeoModel adult, baby;

    public RenderDawnTyrannosaurus(RenderManager rm) {
        super(rm, new net.minecraft.client.model.ModelBase() {}, 1.8F);
    }

    private DawnGeoModel model(boolean child) {
        if (adult == null) {
            adult = new DawnGeoModel(new ResourceLocation(DawnRex.MODID, "geo/geo.json"), new ResourceLocation(DawnRex.MODID, "animations/animation.json"));
            baby = new DawnGeoModel(new ResourceLocation(DawnRex.MODID, "geo/geo_baby.json"), new ResourceLocation(DawnRex.MODID, "animations/animation_baby.json"));
        }
        return child ? baby : adult;
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityDawnTyrannosaurus e) {
        if (e.isChild()) return BABY;
        return e.getGender() == 0 ? FEMALE : MALE;
    }

    @Override
    protected void preRenderCallback(EntityDawnTyrannosaurus e, float partial) {
        float s = e.isChild() ? BABY_SCALE * Math.max(0.25F, e.getAgeScale()) : ADULT_SCALE * e.getAgeScale();
        GlStateManager.scale(s, s, s);
        shadowSize = 1.8F * s;
    }

    @Override
    protected void renderModel(EntityDawnTyrannosaurus e, float ls, float lsa, float age, float yaw, float pitch, float scale) {
        boolean visible = isVisible(e);
        boolean ghost = !visible && !e.isInvisibleToPlayer(Minecraft.getMinecraft().player);
        if (!visible && !ghost) return;
        float pt = Minecraft.getMinecraft().getRenderPartialTicks();
        float now = e.ticksExisted + pt;
        DawnGeoModel m = model(e.isChild());

        String name = "animation.model.idle";
        float time = now / 20f;
        if (lsa > 0.05F) name = "animation.model.walk";
        if (lsa > 0.6F && !e.isInWater()) name = "animation.model.run";
        if (e.isInWater()) name = "animation.model.swim";
        DawnAction a = e.getAction();
        if (a != DawnAction.NONE) { name = a.anim; time = (e.actionTick + pt) / 20f; }
        int transLen = e.sleepTransWake ? 75 : 60;
        if (e.sleepTransTick < transLen) {
            name = e.sleepTransWake ? "animation.model.wake_up" : "animation.model.fall_asleep";
            time = (e.sleepTransTick + pt) / 20f;
        } else if (e.isSleeping()) {
            name = "animation.model.sleep";
        }
        if (!name.equals(e.animCur)) {
            e.animPrev = e.animCur; e.animPrevTime = e.animCurTime; e.animChangeAt = now;
            e.animCur = name;
        }
        e.animCurTime = time;
        float blend = Math.min(1f, (now - e.animChangeAt) / BLEND_TICKS);
        DawnAnimations.Anim prev = e.animPrev.isEmpty() ? null : m.anim(e.animPrev);
        m.pose(m.anim(name), time, prev, e.animPrevTime, blend, yaw, pitch, e.isBeingRidden() && e.isSaddled());

        if (ghost) { GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL); }
        m.renderModel(scale);
        if (ghost) { GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL); }

        // Dawn Era draws saddle/armor as extra passes of the whole model with their own texture
        if (e.isSaddled() && !e.isChild()) overlay(m, SADDLE, scale);
        if (e.isArmored() && !e.isChild()) overlay(m, ARMOR, scale);
    }

    private void overlay(DawnGeoModel m, ResourceLocation tex, float scale) {
        bindTexture(tex);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1F);
        m.renderModel(scale);
        GlStateManager.disableBlend();
    }
}
