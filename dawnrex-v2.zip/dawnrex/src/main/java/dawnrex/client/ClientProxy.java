package dawnrex.client;

import dawnrex.CommonProxy;
import dawnrex.entity.EntityDawnTyrannosaurus;
import net.minecraftforge.fml.client.registry.RenderingRegistry;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit() {
        RenderingRegistry.registerEntityRenderingHandler(EntityDawnTyrannosaurus.class, RenderDawnTyrannosaurus::new);
    }
}
