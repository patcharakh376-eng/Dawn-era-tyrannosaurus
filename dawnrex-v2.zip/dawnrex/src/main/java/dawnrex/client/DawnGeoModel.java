package dawnrex.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dawnrex.anim.DawnAnimations;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.model.ModelBox;
import net.minecraft.client.model.ModelRenderer;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/**
 * Builds a vanilla-style box model at load time from a Bedrock geo.json (Dawn Era format) and poses it from
 * animation.json. Bedrock (x,y,z up) -> Java model space: (-x, 24-y, z); rotations: (-rx, -ry, rz).
 */
@SideOnly(Side.CLIENT)
public class DawnGeoModel extends ModelBase {
    private static final float DEG = (float) Math.PI / 180f;

    private static class Part {
        String name; Part parent;
        List<Part> kids = new ArrayList<>();
        float px, py, pz, rx, ry, rz;
        float ox, oy, oz, arx, ary, arz, sx = 1, sy = 1, sz = 1;
        List<ModelBox> boxes = new ArrayList<>();
        boolean hidden;

        void render(float s) {
            if (hidden) return;
            GlStateManager.pushMatrix();
            GlStateManager.translate((px + ox) * s, (py + oy) * s, (pz + oz) * s);
            float z = rz + arz, y = ry + ary, x = rx + arx;
            if (z != 0) GlStateManager.rotate(z * (180f / (float) Math.PI), 0, 0, 1);
            if (y != 0) GlStateManager.rotate(y * (180f / (float) Math.PI), 0, 1, 0);
            if (x != 0) GlStateManager.rotate(x * (180f / (float) Math.PI), 1, 0, 0);
            if (sx != 1 || sy != 1 || sz != 1) GlStateManager.scale(sx, sy, sz);
            if (!boxes.isEmpty()) {
                BufferBuilder bb = Tessellator.getInstance().getBuffer();
                bb.begin(7, DefaultVertexFormats.POSITION_TEX_NORMAL);
                for (ModelBox b : boxes) b.render(bb, s);
                Tessellator.getInstance().draw();
            }
            for (Part k : kids) k.render(s);
            GlStateManager.popMatrix();
        }
    }

    private final Map<String, Part> parts = new HashMap<>();
    private final List<Part> roots = new ArrayList<>();
    private final Map<String, DawnAnimations.Anim> anims;
    private final float[] tmpA = new float[3], tmpB = new float[3];

    public DawnGeoModel(ResourceLocation geo, ResourceLocation animation) {
        try {
            JsonObject g = new JsonParser().parse(read(geo)).getAsJsonObject()
                    .getAsJsonArray("minecraft:geometry").get(0).getAsJsonObject();
            JsonObject desc = g.getAsJsonObject("description");
            textureWidth = desc.get("texture_width").getAsInt();
            textureHeight = desc.get("texture_height").getAsInt();
            ModelRenderer holder = new ModelRenderer(this, 0, 0);
            Map<String, float[]> pivots = new HashMap<>();
            JsonArray bones = g.getAsJsonArray("bones");
            for (JsonElement el : bones) {
                JsonObject b = el.getAsJsonObject();
                pivots.put(b.get("name").getAsString(), arr(b, "pivot", new float[3]));
            }
            for (JsonElement el : bones) {
                JsonObject b = el.getAsJsonObject();
                Part p = new Part();
                p.name = b.get("name").getAsString();
                float[] pv = pivots.get(p.name);
                float[] jp = {-pv[0], 24 - pv[1], pv[2]};
                String parent = b.has("parent") ? b.get("parent").getAsString() : null;
                if (parent != null && parts.containsKey(parent)) {
                    float[] ppv = pivots.get(parent);
                    p.px = jp[0] + ppv[0]; p.py = jp[1] - (24 - ppv[1]); p.pz = jp[2] - ppv[2];
                    p.parent = parts.get(parent);
                    p.parent.kids.add(p);
                } else {
                    p.px = jp[0]; p.py = jp[1]; p.pz = jp[2];
                    roots.add(p);
                }
                float[] rot = arr(b, "rotation", new float[3]);
                p.rx = -rot[0] * DEG; p.ry = -rot[1] * DEG; p.rz = rot[2] * DEG;
                parts.put(p.name, p);
                if (b.has("cubes")) {
                    for (JsonElement ce : b.getAsJsonArray("cubes")) addCube(holder, p, pv, ce.getAsJsonObject());
                }
            }
        } catch (Exception ex) {
            throw new RuntimeException("dawnrex: failed to load model " + geo, ex);
        }
        try {
            anims = DawnAnimations.parse(read(animation));
        } catch (Exception ex) {
            throw new RuntimeException("dawnrex: failed to load animations " + animation, ex);
        }
    }

    private void addCube(ModelRenderer holder, Part bone, float[] bonePivot, JsonObject c) {
        float[] o = arr(c, "origin", new float[3]), s = arr(c, "size", new float[3]), uv = arr(c, "uv", new float[2]);
        float inflate = c.has("inflate") ? c.get("inflate").getAsFloat() : 0f;
        boolean mirror = c.has("mirror") && c.get("mirror").getAsBoolean();
        Part target = bone;
        float[] piv = bonePivot;
        if (c.has("rotation")) {
            float[] cp = arr(c, "pivot", bonePivot), cr = arr(c, "rotation", new float[3]);
            Part sub = new Part();
            sub.name = bone.name + "_cube";
            sub.px = -(cp[0] - bonePivot[0]); sub.py = -(cp[1] - bonePivot[1]); sub.pz = cp[2] - bonePivot[2];
            sub.rx = -cr[0] * DEG; sub.ry = -cr[1] * DEG; sub.rz = cr[2] * DEG;
            sub.parent = bone; bone.kids.add(sub);
            target = sub; piv = cp;
        }
        float x = piv[0] - o[0] - s[0], y = piv[1] - o[1] - s[1], z = o[2] - piv[2];
        target.boxes.add(new ModelBox(holder, (int) uv[0], (int) uv[1], x, y, z, (int) s[0], (int) s[1], (int) s[2], inflate, mirror));
    }

    private static float[] arr(JsonObject o, String k, float[] def) {
        if (!o.has(k)) return def;
        JsonArray a = o.getAsJsonArray(k);
        float[] r = new float[a.size()];
        for (int i = 0; i < r.length; i++) r[i] = a.get(i).getAsFloat();
        return r;
    }

    private static Reader read(ResourceLocation rl) throws Exception {
        return new InputStreamReader(Minecraft.getMinecraft().getResourceManager().getResource(rl).getInputStream(), "UTF-8");
    }

    public DawnAnimations.Anim anim(String name) {
        DawnAnimations.Anim a = anims.get(name);
        return a != null ? a : anims.get("animation.model.idle");
    }

    private void reset() {
        for (Part p : parts.values()) { p.ox = p.oy = p.oz = p.arx = p.ary = p.arz = 0; p.sx = p.sy = p.sz = 1; }
    }

    private void apply(DawnAnimations.Anim a, float time, float weight, boolean first) {
        if (a == null) return;
        float t = DawnAnimations.localTime(a, time);
        for (Map.Entry<String, DawnAnimations.BoneAnim> e : a.bones.entrySet()) {
            Part p = parts.get(e.getKey());
            if (p == null) continue;
            DawnAnimations.BoneAnim ba = e.getValue();
            if (ba.rot != null) {
                DawnAnimations.sample(ba.rot, t, tmpA);
                p.arx += -tmpA[0] * DEG * weight; p.ary += -tmpA[1] * DEG * weight; p.arz += tmpA[2] * DEG * weight;
            }
            if (ba.pos != null) {
                DawnAnimations.sample(ba.pos, t, tmpA);
                p.ox += -tmpA[0] * weight; p.oy += -tmpA[1] * weight; p.oz += tmpA[2] * weight;
            }
            if (ba.scl != null) {
                DawnAnimations.sample(ba.scl, t, tmpA);
                p.sx = lerp(p.sx, tmpA[0], weight); p.sy = lerp(p.sy, tmpA[1], weight); p.sz = lerp(p.sz, tmpA[2], weight);
            }
        }
    }

    private static float lerp(float a, float b, float w) { return a + (b - a) * w; }

    /** Pose = blend(prev, cur) + head look + reins visibility. blend 0..1 (1 = fully current). */
    public void pose(DawnAnimations.Anim cur, float curTime, DawnAnimations.Anim prev, float prevTime, float blend,
                     float headYaw, float headPitch, boolean showReins) {
        reset();
        if (prev != null && blend < 1f) apply(prev, prevTime, 1f - blend, true);
        apply(cur, curTime, prev != null && blend < 1f ? blend : 1f, false);
        Part neck = parts.get("neck");
        if (neck != null) {
            neck.ary += Math.max(-60f, Math.min(60f, headYaw)) * DEG;
            neck.arx += Math.max(-20f, Math.min(20f, headPitch)) * DEG;
        }
        Part reins = parts.get("reins");
        if (reins != null) reins.hidden = !showReins;
    }

    public void renderModel(float scale) {
        for (Part p : roots) p.render(scale);
    }
}
