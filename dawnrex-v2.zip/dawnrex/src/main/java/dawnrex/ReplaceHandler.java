package dawnrex;

import dawnrex.entity.EntityDawnTyrannosaurus;
import fossilsarcheology.server.entity.prehistoric.EntityTyrannosaurus;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.entity.Entity;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.world.World;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;

/**
 * Replaces any exact-class Fossils EntityTyrannosaurus with EntityDawnTyrannosaurus, keeping its NBT
 * (age, hunger, owner, gender, ...). The respawn is deferred to the world tick, because spawning inside
 * the join event of a chunk that is still loading would silently lose the entity.
 */
public class ReplaceHandler {
    private static class Pending {
        final World world; final NBTTagCompound nbt;
        Pending(World w, NBTTagCompound n) { world = w; nbt = n; }
    }
    private final List<Pending> pending = new ArrayList<>();

    @SubscribeEvent
    public void onJoin(EntityJoinWorldEvent e) {
        Entity en = e.getEntity();
        if (e.getWorld().isRemote || en.getClass() != EntityTyrannosaurus.class) return;
        NBTTagCompound nbt = new NBTTagCompound();
        en.writeToNBT(nbt);
        en.setDead();
        e.setCanceled(true);
        pending.add(new Pending(e.getWorld(), nbt));
    }

    @SubscribeEvent
    public void onTick(TickEvent.WorldTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.world.isRemote || pending.isEmpty()) return;
        Iterator<Pending> it = pending.iterator();
        while (it.hasNext()) {
            Pending p = it.next();
            if (p.world != e.world) continue;
            it.remove();
            EntityDawnTyrannosaurus n = new EntityDawnTyrannosaurus(p.world);
            n.readFromNBT(p.nbt);
            p.world.spawnEntity(n);
        }
    }
}
