package dawnrex;

public class CommonProxy {
    public void preInit() {}
}
