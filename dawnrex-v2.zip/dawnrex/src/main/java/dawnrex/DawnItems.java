package dawnrex;

import net.minecraft.creativetab.CreativeTabs;
import net.minecraft.item.Item;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = DawnRex.MODID)
public class DawnItems {
    public static final Item SADDLE = new Item().setRegistryName(DawnRex.MODID, "tyrannosaurus_saddle")
            .setTranslationKey("tyrannosaurus_saddle").setCreativeTab(CreativeTabs.MISC).setMaxStackSize(1);
    public static final Item ARMOR = new Item().setRegistryName(DawnRex.MODID, "tyrannosaurus_armor")
            .setTranslationKey("tyrannosaurus_armor").setCreativeTab(CreativeTabs.MISC).setMaxStackSize(1);

    @SubscribeEvent
    public static void register(RegistryEvent.Register<Item> e) {
        e.getRegistry().registerAll(SADDLE, ARMOR);
    }
}
