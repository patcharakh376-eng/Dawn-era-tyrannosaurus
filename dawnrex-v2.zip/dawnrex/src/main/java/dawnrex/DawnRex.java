package dawnrex;

import dawnrex.entity.EntityDawnTyrannosaurus;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.SidedProxy;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.registry.EntityRegistry;

/** Addon: replaces the Fossils & Archeology T-Rex with a Dawn Era style Tyrannosaurus. */
@Mod(modid = DawnRex.MODID, name = "Dawn Rex", version = "1.0.0",
        dependencies = "required-after:fossil", acceptedMinecraftVersions = "[1.12.2]")
public class DawnRex {
    public static final String MODID = "dawnrex";

    @Mod.Instance(MODID)
    public static DawnRex INSTANCE;

    @SidedProxy(clientSide = "dawnrex.client.ClientProxy", serverSide = "dawnrex.CommonProxy")
    public static CommonProxy proxy;

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // Entity is registered in preInit, before any world/chunk can load.
        EntityRegistry.registerModEntity(new ResourceLocation(MODID, "dawn_tyrannosaurus"),
                EntityDawnTyrannosaurus.class, "dawn_tyrannosaurus", 1, this, 96, 1, true,
                0x4A5A2C, 0xB0A070);
        // Swaps every old Fossils T-Rex (spawned, hatched, or loaded from a save) for the new one.
        MinecraftForge.EVENT_BUS.register(new ReplaceHandler());
        proxy.preInit();
    }
}
