package dawnrex;

import net.minecraft.util.ResourceLocation;
import net.minecraft.util.SoundEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = DawnRex.MODID)
public class DawnSounds {
    public static final SoundEvent ATTACK = make("attack");
    public static final SoundEvent ATTACK_GROUND = make("attack_ground");
    public static final SoundEvent DEATH = make("death");
    public static final SoundEvent HURT = make("hurt");
    public static final SoundEvent IDLE = make("idle");
    public static final SoundEvent RAM = make("ram");
    public static final SoundEvent ROAR = make("roar");
    public static final SoundEvent SLEEP = make("sleep");
    public static final SoundEvent SNIFF = make("sniff");
    public static final SoundEvent STEP = make("step");
    public static final SoundEvent YAWN = make("yawn");

    private static SoundEvent make(String name) {
        ResourceLocation rl = new ResourceLocation(DawnRex.MODID, "entity.tyrannosaurus." + name);
        return new SoundEvent(rl).setRegistryName(rl);
    }

    @SubscribeEvent
    public static void register(RegistryEvent.Register<SoundEvent> e) {
        e.getRegistry().registerAll(ATTACK, ATTACK_GROUND, DEATH, HURT, IDLE, RAM, ROAR, SLEEP, SNIFF, STEP, YAWN);
    }
}
