package dawnrex.entity;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.ai.EntityAIBase;

/** Replaces the old Fossils DinoMeleeAttackAI: chase, optional roar, then play a random Dawn attack action. */
public class DawnAIMelee extends EntityAIBase {
    private final EntityDawnTyrannosaurus rex;
    private final double speed;
    private int repath;
    private int cooldown;

    public DawnAIMelee(EntityDawnTyrannosaurus rex, double speed) {
        this.rex = rex;
        this.speed = speed;
        setMutexBits(3);
    }

    @Override
    public boolean shouldExecute() {
        EntityLivingBase t = rex.getAttackTarget();
        return t != null && t.isEntityAlive() && !rex.isSleeping() && !rex.isSitting() && rex.getRidingPlayer() == null;
    }

    @Override
    public boolean shouldContinueExecuting() {
        return shouldExecute();
    }

    @Override
    public void startExecuting() {
        repath = 0;
        if (rex.isAdult() && !rex.isInWater() && rex.getAction() == DawnAction.NONE && rex.getRNG().nextInt(100) < 30) {
            rex.startAction(DawnAction.ROAR);
        }
    }

    @Override
    public void updateTask() {
        EntityLivingBase t = rex.getAttackTarget();
        if (t == null) return;
        if (cooldown > 0) cooldown--;
        if (rex.getAction() != DawnAction.ROAR) rex.getLookHelper().setLookPositionWithEntity(t, 30.0F, 30.0F);
        if (--repath <= 0) {
            repath = 10;
            rex.getNavigator().tryMoveToEntityLiving(t, speed);
        }
        float gap = rex.getDistance(t) - (rex.width + t.width) * 0.5F;
        if (gap <= 2.0F && rex.getAction() == DawnAction.NONE && cooldown <= 0) {
            rex.faceEntity(t, 60.0F, 60.0F);
            rex.startAction(rex.pickAttack());
            cooldown = 10;
        }
    }

    @Override
    public void resetTask() {
        rex.getNavigator().clearPath();
    }
}
