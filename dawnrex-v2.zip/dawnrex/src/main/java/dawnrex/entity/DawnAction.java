package dawnrex.entity;

/** Replacement for AstemirLib ActionState. Lengths come from Dawn Era tyrannosaurus.json (seconds * 20). */
public enum DawnAction {
    NONE("", 0),
    ATTACK1("animation.model.attack1", 15),
    ATTACK2("animation.model.attack2", 19),
    RAM("animation.model.attack3", 20),
    GROUND("animation.model.attack4", 24),
    ROAR("animation.model.roar", 81),
    SNIFF("animation.model.sniff", 39),
    EAT("animation.model.eat", 66);

    public final String anim;
    public final int length;

    DawnAction(String anim, int length) { this.anim = anim; this.length = length; }

    public static DawnAction byId(int id) {
        DawnAction[] v = values();
        return id >= 0 && id < v.length ? v[id] : NONE;
    }
}
