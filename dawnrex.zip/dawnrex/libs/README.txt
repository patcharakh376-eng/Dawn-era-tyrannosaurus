put fossilsarcheology-8.0.6.jar and llibrary-1.7.20.jar here
