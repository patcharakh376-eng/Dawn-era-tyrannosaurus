package dawnrex.entity;

import dawnrex.DawnItems;
import dawnrex.DawnSounds;
import fossilsarcheology.server.entity.ai.*;
import fossilsarcheology.server.entity.prehistoric.EntityTyrannosaurus;
import java.util.List;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.block.Block;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.entity.ai.attributes.IAttributeInstance;
import net.minecraft.entity.passive.EntityTameable;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumHand;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

/**
 * Dawn Era style Tyrannosaurus built on top of the Fossils T-Rex (so eggs, DNA, dinopedia, taming,
 * hunger and instanceof checks keep working). AI, attacks, sounds, saddle, armor and animation state
 * are replaced by the Dawn Era behaviour.
 */
public class EntityDawnTyrannosaurus extends EntityTyrannosaurus {
    private static final DataParameter<Integer> ACTION = EntityDataManager.createKey(EntityDawnTyrannosaurus.class, DataSerializers.VARINT);
    private static final DataParameter<Boolean> SADDLED = EntityDataManager.createKey(EntityDawnTyrannosaurus.class, DataSerializers.BOOLEAN);
    private static final DataParameter<Boolean> ARMORED = EntityDataManager.createKey(EntityDawnTyrannosaurus.class, DataSerializers.BOOLEAN);
    private static final UUID ARMOR_UUID = UUID.fromString("5b2d7a3e-6e53-4a52-9d8a-3f0f6c1d9a11");
    /** Extra armor points while wearing the Tyrannosaurus Armor item. */
    private static final double ARMOR_BONUS = 15.0D;
    /** Multiplies Fossils attack damage. Dawn Era values are 1.25 (players) / 1.55 (others). */
    private static final float DAMAGE_SCALE = 1.0F;

    public int actionTick;
    // client-side animation state (plain data, only read by the renderer)
    public String animCur = "";
    public String animPrev = "";
    public float animCurTime, animPrevTime, animChangeAt;
    private boolean wasSleeping;
    public int sleepTransTick = 1000;
    public boolean sleepTransWake;

    public EntityDawnTyrannosaurus(World world) {
        super(world);
    }

    @Override
    protected void entityInit() {
        super.entityInit();
        dataManager.register(ACTION, 0);
        dataManager.register(SADDLED, false);
        dataManager.register(ARMORED, false);
    }

    /** The whole old Fossils T-Rex task list is dropped and replaced. */
    @Override
    protected void initEntityAI() {
        this.aiSit = new EntityAISit(this);
        this.tasks.addTask(0, new EntityAISwimming(this));
        this.tasks.addTask(1, this.aiSit);
        this.tasks.addTask(2, new DawnAIMelee(this, 1.7D));
        this.tasks.addTask(3, new DinoAIRiding(this, 1.0D));
        this.tasks.addTask(4, new DinoAIFollowOwner(this, 1.7D, 10.0F, 3.0F));
        this.tasks.addTask(5, new DinoAIEatFeedersAndBlocks(this));
        this.tasks.addTask(5, new DinoAIEatItems(this));
        this.tasks.addTask(6, new DinoAIWander(this, 0.8D));
        this.tasks.addTask(7, new DinoAIWatchClosest(this, EntityPlayer.class, 8.0F));
        this.tasks.addTask(8, new DinoAILookIdle(this));
        this.targetTasks.addTask(0, new DinoAIOwnerHurtByTarget(this));
        this.targetTasks.addTask(1, new DinoAIOwnerHurtTarget(this));
        this.targetTasks.addTask(2, new DinoAIHurtByTarget(this));
        this.targetTasks.addTask(3, new DinoAIHunt<EntityLivingBase>(this, EntityLivingBase.class, true, e -> e instanceof EntityLivingBase));
    }

    // ---------------------------------------------------------------- actions

    public DawnAction getAction() {
        return DawnAction.byId(dataManager.get(ACTION));
    }

    public void startAction(DawnAction a) {
        if (world.isRemote || a == DawnAction.NONE) return;
        if (a != DawnAction.ROAR && getAction() != DawnAction.NONE) return;
        dataManager.set(ACTION, a.ordinal());
        actionTick = 0;
        if (a == DawnAction.ATTACK1 || a == DawnAction.ATTACK2) playSound(DawnSounds.ATTACK, 1.0F, getSoundPitch());
        if (a == DawnAction.RAM) playSound(DawnSounds.RAM, 1.0F, getSoundPitch());
    }

    @Override
    public void notifyDataManagerChange(DataParameter<?> key) {
        super.notifyDataManagerChange(key);
        if (ACTION.equals(key)) actionTick = 0;
    }

    public DawnAction pickAttack() {
        int r = rand.nextInt(100);
        if (!isAdult()) return DawnAction.ATTACK1;
        if (r < 30) return DawnAction.ATTACK1;
        if (r < 60) return DawnAction.ATTACK2;
        if (r < 80) return DawnAction.RAM;
        return onGround ? DawnAction.GROUND : DawnAction.ATTACK1;
    }

    private boolean isLocked() {
        return getAction() != DawnAction.NONE;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        DawnAction a = getAction();
        if (a != DawnAction.NONE) {
            if (actionTick < a.length) actionTick++;
            if (!world.isRemote) {
                serverActionTick(a, actionTick);
                if (actionTick >= a.length) {
                    dataManager.set(ACTION, 0);
                    actionTick = 0;
                }
            }
        } else if (!world.isRemote && !isSleeping() && getRidingPlayer() == null && getAttackTarget() == null && !isInWater()) {
            if (rand.nextInt(1500) == 0) startAction(DawnAction.ROAR);
            else if (isHungry() && rand.nextInt(700) == 0) startAction(DawnAction.SNIFF);
        }
        if (world.isRemote) {
            if (isSleeping() != wasSleeping) {
                wasSleeping = isSleeping();
                sleepTransWake = !wasSleeping;
                sleepTransTick = 0;
            }
            if (sleepTransTick < 1000) sleepTransTick++;
        }
    }

    private void serverActionTick(DawnAction a, int t) {
        switch (a) {
            case ATTACK1:
                if (t == 10) meleeHit(1.25F, 1.55F, true);
                break;
            case ATTACK2:
                if (t == 12) meleeHit(1.25F, 1.55F, true);
                break;
            case RAM:
                if (t == 7) {
                    meleeHit(1.15F, 2.0F, false);
                    meleeFrontArea(3.5D, 0.7F);
                }
                break;
            case GROUND:
                if (t == 5) playSound(DawnSounds.ATTACK_GROUND, 1.6F, getSoundPitch());
                if (t == 12) groundSlam();
                break;
            case ROAR:
                if (t == 15) playSound(DawnSounds.ROAR, 3.0F, getSoundPitch());
                break;
            case SNIFF:
                if (t == 10) playSound(DawnSounds.SNIFF, 1.0F, getSoundPitch() * 0.65F);
                break;
            case EAT:
                if (t == 1) playSound(SoundEvents.ENTITY_GENERIC_EAT, 1.0F, getSoundPitch() * 0.7F);
                break;
            default:
                break;
        }
    }

    private boolean isFriendly(Entity e, @Nullable EntityPlayer rider) {
        if (e == this || e.getClass() == this.getClass() || this.isPassenger(e) || e == rider) return true;
        if (e instanceof EntityTameable) {
            EntityTameable pet = (EntityTameable) e;
            if (rider != null && pet.isOwner(rider)) return true;
            if (getOwner() != null && pet.isOwner(getOwner())) return true;
        }
        return e instanceof EntityPlayer && isTamed() && isOwner((EntityPlayer) e);
    }

    private void damage(EntityLivingBase t, float mult) {
        float dmg = (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * mult * DAMAGE_SCALE;
        t.attackEntityFrom(DamageSource.causeMobDamage(this), dmg);
    }

    /** Bite / ram: a hit on the AI target, or on everything in front when a player rides. */
    private void meleeHit(float playerMult, float otherMult, boolean fracture) {
        EntityPlayer rider = getRidingPlayer();
        if (rider == null) {
            EntityLivingBase t = getAttackTarget();
            if (t != null && getDistance(t) - (width + t.width) * 0.5F <= 2.6F) hitOne(t, playerMult, otherMult, fracture);
        } else {
            for (EntityLivingBase t : frontEntities(4.5D)) hitOne(t, playerMult, otherMult, fracture);
        }
    }

    private void hitOne(EntityLivingBase t, float playerMult, float otherMult, boolean fracture) {
        damage(t, t instanceof EntityPlayer ? playerMult : otherMult);
        if (fracture && !isChild()) t.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 180, 1, true, false));
        Vec3d look = getLookVec();
        t.motionX += look.x * 0.5D;
        t.motionZ += look.z * 0.5D;
        t.motionY += 0.25D;
        t.velocityChanged = true;
    }

    private void meleeFrontArea(double reach, float mult) {
        for (EntityLivingBase t : frontEntities(reach)) {
            if (t != getAttackTarget()) damage(t, mult);
        }
    }

    private List<EntityLivingBase> frontEntities(double reach) {
        EntityPlayer rider = getRidingPlayer();
        float yaw = renderYawOffset * 0.017453292F;
        Vec3d fwd = new Vec3d(-MathHelper.sin(yaw), 0.0D, MathHelper.cos(yaw));
        List<EntityLivingBase> all = world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(reach, 1.5D, reach));
        all.removeIf(e -> {
            if (isFriendly(e, rider)) return true;
            Vec3d d = new Vec3d(e.posX - posX, 0.0D, e.posZ - posZ);
            double len = d.lengthVector();
            return len > 0.001D && d.scale(1.0D / len).dotProduct(fwd) < 0.3D;
        });
        return all;
    }

    private void groundSlam() {
        EntityPlayer rider = getRidingPlayer();
        List<EntityLivingBase> list = world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(3.5D, 2.0D, 3.5D));
        for (EntityLivingBase e : list) {
            if (isFriendly(e, rider)) continue;
            e.attackEntityFrom(DamageSource.causeMobDamage(this), 30.0F * DAMAGE_SCALE);
            e.addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 100, 2, true, false));
            e.motionY += 0.5D;
            e.velocityChanged = true;
        }
        if (world instanceof WorldServer) {
            ((WorldServer) world).spawnParticle(EnumParticleTypes.EXPLOSION_NORMAL, posX, posY + 0.2D, posZ, 30, 2.0D, 0.1D, 2.0D, 0.02D);
        }
    }

    // ---------------------------------------------------------------- movement / steps

    @Override
    public void travel(float strafe, float vertical, float forward) {
        if (isLocked()) {
            strafe = 0.0F;
            forward = 0.0F;
        }
        super.travel(strafe, vertical, forward);
        if (isLocked()) {
            motionX = 0.0D;
            motionZ = 0.0D;
        }
    }

    @Override
    protected void playStepSound(BlockPos pos, Block block) {
        if (isChild() || isInWater()) return;
        playSound(DawnSounds.STEP, 1.0F, getSoundPitch());
        if (!world.isRemote) {
            // trample small mobs under the feet, like Dawn Era onServerMobStep
            for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(0.5D).expand(0, -0.5D, 0))) {
                if (isFriendly(e, getRidingPlayer()) || e.height / height >= 0.5F) continue;
                e.attackEntityFrom(DamageSource.causeMobDamage(this), (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * 0.45F);
            }
        }
    }

    // ---------------------------------------------------------------- rider input (Fossils hooks)

    @Override
    public void playerAttack(EntityPlayer player) {
        if (!isSleeping() && getAction() == DawnAction.NONE) startAction(pickAttack());
    }

    @Override
    public void playerRoar(EntityPlayer player) {
        if (!isSleeping()) startAction(DawnAction.ROAR);
    }

    @Override
    public void eatItem(ItemStack stack) {
        super.eatItem(stack);
        startAction(DawnAction.EAT);
    }

    /** Riding (Fossils whip) now requires a saddle, like Dawn Era RequiresSaddle. */
    @Override
    public boolean canBeRidden() {
        return isSaddled();
    }

    // ---------------------------------------------------------------- saddle / armor

    public boolean isSaddled() { return dataManager.get(SADDLED); }
    public boolean isArmored() { return dataManager.get(ARMORED); }

    public void setSaddled(boolean v) {
        dataManager.set(SADDLED, v);
    }

    public void setArmored(boolean v) {
        dataManager.set(ARMORED, v);
        if (world.isRemote) return;
        IAttributeInstance attr = getEntityAttribute(SharedMonsterAttributes.ARMOR);
        if (attr.getModifier(ARMOR_UUID) != null) attr.removeModifier(ARMOR_UUID);
        if (v) attr.applyModifier(new AttributeModifier(ARMOR_UUID, "dawnrex armor", ARMOR_BONUS, 0));
    }

    @Override
    public boolean processInteract(EntityPlayer player, EnumHand hand) {
        ItemStack s = player.getHeldItem(hand);
        if (isTamed() && isOwner(player) && isAdult()) {
            if (s.getItem() == DawnItems.SADDLE && !isSaddled()) {
                if (!world.isRemote) {
                    setSaddled(true);
                    playSound(SoundEvents.ENTITY_HORSE_SADDLE, 0.5F, 1.0F);
                    if (!player.capabilities.isCreativeMode) s.shrink(1);
                }
                return true;
            }
            if (s.getItem() == DawnItems.ARMOR && !isArmored()) {
                if (!world.isRemote) {
                    setArmored(true);
                    playSound(SoundEvents.ENTITY_HORSE_ARMOR, 0.5F, 1.0F);
                    if (!player.capabilities.isCreativeMode) s.shrink(1);
                }
                return true;
            }
            if (s.isEmpty() && player.isSneaking() && getRidingPlayer() == null && (isSaddled() || isArmored())) {
                if (!world.isRemote) {
                    if (isArmored()) { setArmored(false); entityDropItem(new ItemStack(DawnItems.ARMOR), 1.0F); }
                    else { setSaddled(false); entityDropItem(new ItemStack(DawnItems.SADDLE), 1.0F); }
                }
                return true;
            }
        }
        return super.processInteract(player, hand);
    }

    @Override
    public void onDeath(DamageSource cause) {
        if (!world.isRemote) {
            if (isSaddled()) entityDropItem(new ItemStack(DawnItems.SADDLE), 0.5F);
            if (isArmored()) entityDropItem(new ItemStack(DawnItems.ARMOR), 0.5F);
        }
        super.onDeath(cause);
    }

    @Override
    public void writeEntityToNBT(NBTTagCompound c) {
        super.writeEntityToNBT(c);
        c.setBoolean("DawnSaddled", isSaddled());
        c.setBoolean("DawnArmored", isArmored());
    }

    @Override
    public void readEntityFromNBT(NBTTagCompound c) {
        super.readEntityFromNBT(c);
        setSaddled(c.getBoolean("DawnSaddled"));
        setArmored(c.getBoolean("DawnArmored"));
    }

    // ---------------------------------------------------------------- sounds

    @Override
    protected SoundEvent getAmbientSound() {
        if (getAction() != DawnAction.NONE) return null;
        return isSleeping() ? DawnSounds.SLEEP : DawnSounds.IDLE;
    }

    @Override
    protected SoundEvent getHurtSound(DamageSource src) { return DawnSounds.HURT; }

    @Override
    protected SoundEvent getDeathSound() { return DawnSounds.DEATH; }

    /** The old speak animation is gone: just play the idle sound. */
    @Override
    public void playLivingSound() {
        SoundEvent s = getAmbientSound();
        if (s != null) playSound(s, getSoundVolume(), getSoundPitch());
    }
}
