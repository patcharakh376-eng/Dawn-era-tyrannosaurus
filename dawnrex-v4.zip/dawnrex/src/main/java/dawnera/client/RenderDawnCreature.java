package dawnera.client;

import dawnera.DawnEra;
import dawnera.anim.DawnAnimations;
import dawnera.entity.EntityDawnCreature;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.RenderLiving;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** One renderer for every Dawn Era creature. Files are looked up by species id (geo/<id>/geo.json, ...). */
@SideOnly(Side.CLIENT)
public class RenderDawnCreature<T extends EntityDawnCreature> extends RenderLiving<T> {
    private static final float BLEND_TICKS = 3.0F; // 0.15s like Dawn Era
    private final Map<String, DawnGeoModel[]> models = new HashMap<>();
    private final float baseShadow;

    public RenderDawnCreature(RenderManager rm, float shadow) {
        super(rm, new ModelBase() {}, shadow);
        this.baseShadow = shadow;
    }

    private static ResourceLocation rl(String path) { return new ResourceLocation(DawnEra.MODID, path); }

    private DawnGeoModel model(String id, boolean child) {
        DawnGeoModel[] m = models.get(id);
        if (m == null) {
            m = new DawnGeoModel[]{
                    new DawnGeoModel(rl("geo/" + id + "/geo.json"), rl("animations/" + id + "/animation.json")),
                    new DawnGeoModel(rl("geo/" + id + "/geo_baby.json"), rl("animations/" + id + "/animation_baby.json"))};
            models.put(id, m);
        }
        return m[child ? 1 : 0];
    }

    private ResourceLocation tex(T e, String name) {
        return rl("textures/entity/" + e.getSpeciesId() + "/" + name + ".png");
    }

    @Override
    protected ResourceLocation getEntityTexture(T e) {
        if (e.isChild()) return tex(e, "baby");
        return tex(e, e.isMale() ? "male" : "female");
    }

    @Override
    protected void preRenderCallback(T e, float partial) {
        float s = e.isChild() ? 0.8F + 0.4F * e.getGrowthProgress() : 1.0F;
        GlStateManager.scale(s, s, s);
        shadowSize = baseShadow * s;
    }

    @Override
    protected void renderModel(T e, float ls, float lsa, float age, float yaw, float pitch, float scale) {
        boolean visible = isVisible(e);
        boolean ghost = !visible && !e.isInvisibleToPlayer(Minecraft.getMinecraft().player);
        if (!visible && !ghost) return;
        float pt = Minecraft.getMinecraft().getRenderPartialTicks();
        float now = e.ticksExisted + pt;
        DawnGeoModel m = model(e.getSpeciesId(), e.isChild());

        String name = "animation.model.idle";
        float time = now / 20f;
        if (lsa > 0.05F) name = "animation.model.walk";
        if (lsa > 0.6F && !e.isInWater()) name = "animation.model.run";
        if (e.isInWater()) name = "animation.model.swim";
        EntityDawnCreature.Action a = e.getAction();
        if (a != null) { name = a.anim; time = (e.actionTick + pt) / 20f; }
        int transLen = e.sleepTransWake ? 75 : 60;
        if (e.sleepTransTick < transLen) {
            name = e.sleepTransWake ? "animation.model.wake_up" : "animation.model.fall_asleep";
            time = (e.sleepTransTick + pt) / 20f;
        } else if (e.isDawnSleeping()) {
            name = "animation.model.sleep";
        }
        if (!name.equals(e.animCur)) {
            e.animPrev = e.animCur; e.animPrevTime = e.animCurTime; e.animChangeAt = now;
            e.animCur = name;
        }
        e.animCurTime = time;
        float blend = Math.min(1f, (now - e.animChangeAt) / BLEND_TICKS);
        DawnAnimations.Anim prev = e.animPrev.isEmpty() ? null : m.anim(e.animPrev);
        m.pose(m.anim(name), time, prev, e.animPrevTime, blend, yaw, pitch, e.isBeingRidden() && e.isSaddled());

        if (ghost) GlStateManager.enableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);
        m.renderModel(scale);
        if (ghost) GlStateManager.disableBlendProfile(GlStateManager.Profile.TRANSPARENT_MODEL);

        // Dawn Era draws saddle/armor as extra passes of the whole model with their own texture
        if (e.isSaddled() && !e.isChild()) overlay(m, tex(e, "saddle_0"), scale);
        if (e.isArmored() && !e.isChild()) overlay(m, tex(e, "armor_0"), scale);
    }

    private void overlay(DawnGeoModel m, ResourceLocation tex, float scale) {
        bindTexture(tex);
        GlStateManager.enableBlend();
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.enableAlpha();
        GlStateManager.alphaFunc(516, 0.1F);
        m.renderModel(scale);
        GlStateManager.disableBlend();
    }
}
