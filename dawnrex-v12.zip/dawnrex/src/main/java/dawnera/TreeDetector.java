package dawnera;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraftforge.oredict.OreDictionary;

/** Finds the logs and leaves that belong to one tree (Dawn Era TreeDetector, adapted to 1.12.2 blocks). */
public class TreeDetector {
    private static final Map<Block, Boolean> LOG_CACHE = new HashMap<>();
    private static final Map<Block, Boolean> LEAF_CACHE = new HashMap<>();

    private static boolean ore(Block b, String name, Map<Block, Boolean> cache) {
        Boolean c = cache.get(b);
        if (c != null) return c;
        boolean r = false;
        try {
            Item it = Item.getItemFromBlock(b);
            if (it != Items.AIR) {
                for (int id : OreDictionary.getOreIDs(new ItemStack(it, 1, 0))) {
                    if (OreDictionary.getOreName(id).equals(name)) { r = true; break; }
                }
            }
        } catch (Exception ignored) { }
        cache.put(b, r);
        return r;
    }

    public static boolean isLog(IBlockState s) {
        Block b = s.getBlock();
        return b instanceof BlockLog || ore(b, "logWood", LOG_CACHE);
    }

    public static boolean isLeaves(IBlockState s) {
        Block b = s.getBlock();
        return b instanceof BlockLeaves || ore(b, "treeLeaves", LEAF_CACHE);
    }

    /** Leaves that count as part of a tree (player-placed "persistent" leaves do not). */
    private static boolean checkLeaves(IBlockState s) {
        if (!isLeaves(s)) return false;
        if (s.getPropertyKeys().contains(BlockLeaves.DECAYABLE) && !s.getValue(BlockLeaves.DECAYABLE)) return false;
        return true;
    }

    public static BlockPos bottomOfTree(World w, BlockPos pos) {
        int guard = 0;
        while (pos.getY() > 1 && guard++ < 96) {
            IBlockState s = w.getBlockState(pos);
            if (!(isLeaves(s) || s.getMaterial() == Material.AIR || isLog(s))) break;
            pos = pos.down();
        }
        return pos.up();
    }

    public static boolean isNormalRotatedLog(World w, BlockPos pos) {
        IBlockState s = w.getBlockState(pos);
        if (s.getBlock() instanceof BlockLog && s.getPropertyKeys().contains(BlockLog.LOG_AXIS)) {
            return s.getValue(BlockLog.LOG_AXIS) == BlockLog.EnumAxis.Y;
        }
        return false;
    }

    /** Logs above and beside the start (Dawn: offsets -1..1, 0..1, -1..1 from every log). Stops if there are more than maxLogs. */
    public static void searchForLogs(World w, BlockPos start, int maxLogs, Set<BlockPos> logs) {
        Deque<BlockPos> stack = new ArrayDeque<>();
        Set<BlockPos> looped = new java.util.HashSet<>();
        stack.add(start);
        looped.add(start);
        while (!stack.isEmpty() && looped.size() < 4000) {
            BlockPos p = stack.poll();
            if (!isLog(w.getBlockState(p))) continue;
            logs.add(p);
            if (logs.size() > maxLogs) return;
            for (int dx = -1; dx <= 1; dx++)
                for (int dy = 0; dy <= 1; dy++)
                    for (int dz = -1; dz <= 1; dz++) {
                        BlockPos n = p.add(dx, dy, dz);
                        if (Math.abs(n.getX() - start.getX()) > 14 || Math.abs(n.getZ() - start.getZ()) > 14
                                || n.getY() > start.getY() + 60) continue;
                        if (looped.add(n)) stack.add(n);
                    }
        }
    }

    /** Leaves reachable from the logs through at most 6 leaf blocks. */
    public static void searchForLeaves(World w, Set<BlockPos> logs, Set<BlockPos> leaves) {
        Deque<BlockPos> queue = new ArrayDeque<>();
        Deque<Integer> depth = new ArrayDeque<>();
        Set<BlockPos> seen = new java.util.HashSet<>();
        for (BlockPos log : logs) {
            for (EnumFacing f : EnumFacing.values()) {
                BlockPos n = log.offset(f);
                if (seen.add(n)) { queue.add(n); depth.add(1); }
            }
        }
        while (!queue.isEmpty() && seen.size() < 6000) {
            BlockPos p = queue.poll();
            int d = depth.poll();
            if (d >= 7) continue;
            if (!checkLeaves(w.getBlockState(p))) continue;
            leaves.add(p);
            for (EnumFacing f : EnumFacing.values()) {
                BlockPos n = p.offset(f);
                if (seen.add(n)) { queue.add(n); depth.add(d + 1); }
            }
        }
    }

    public static BlockPos nearestGround(World w, BlockPos pos) {
        int guard = 0;
        while (pos.getY() > 1 && guard++ < 64) {
            BlockPos below = pos.down();
            if (!w.getBlockState(below).getBlock().isReplaceable(w, below)) break;
            pos = below;
        }
        return pos;
    }
}
