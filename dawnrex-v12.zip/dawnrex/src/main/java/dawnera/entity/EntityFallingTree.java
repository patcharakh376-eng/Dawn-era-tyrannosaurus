package dawnera.entity;

import dawnera.DawnNetwork;
import dawnera.DawnSounds;
import dawnera.TreeDetector;
import io.netty.buffer.ByteBuf;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLog;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.Entity;
import net.minecraft.init.Blocks;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraftforge.fml.common.registry.IEntityAdditionalSpawnData;

/**
 * Dawn Era EntityFallingTree: the blocks of a whole tree are turned into one entity that topples away from whatever
 * pushed it, then the tree is put back down as blocks lying on the ground (logs turned sideways).
 */
public class EntityFallingTree extends Entity implements IEntityAdditionalSpawnData {
    public static class Node {
        public final BlockPos offset;
        public final IBlockState state;
        public Node(BlockPos offset, IBlockState state) { this.offset = offset; this.state = state; }
    }

    /** Length of the fall in ticks (Dawn Era: about 10; slower here so it is easier to see). */
    public static final int FALL_TICKS = 20;

    private final List<Node> nodes = new ArrayList<>();
    public int fallTicks;

    public EntityFallingTree(World world) {
        super(world);
        setSize(0.5F, 0.5F);
        this.noClip = true;
        this.ignoreFrustumCheck = true;   // the tree is much bigger than the entity box
    }

    @Override protected void entityInit() {}

    public List<Node> getNodes() { return nodes; }

    /** Fall angle in degrees (0 standing, 90 lying), accelerating like a falling tree. */
    public float getAngle(float partial) {
        float t = Math.min(1.0F, (fallTicks + partial) / (float) FALL_TICKS);
        return 90.0F * t * t;
    }

    @Override
    public void onUpdate() {
        super.onUpdate();
        fallTicks++;
        if (!world.isRemote && getAngle(0.0F) > 75.0F) land();
    }

    private void land() {
        double yaw = Math.toRadians(rotationYaw);
        double cy = Math.cos(yaw), sy = Math.sin(yaw);
        BlockPos base = new BlockPos(posX, posY, posZ);
        BlockLog.EnumAxis axis = (rotationYaw >= 45.0F && rotationYaw <= 135.0F) || (rotationYaw >= -135.0F && rotationYaw <= -45.0F)
                ? BlockLog.EnumAxis.X : BlockLog.EnumAxis.Z;
        for (Node n : nodes) {
            // Dawn Era: rotateX(90 degrees) then rotateY(yaw)
            double x = n.offset.getX(), y = n.offset.getY(), z = n.offset.getZ();
            double rx = x, ry = -z, rz = y;
            double fx = rx * cy + rz * sy;
            double fz = -rx * sy + rz * cy;
            BlockPos p = base.add((int) Math.floor(fx), (int) Math.floor(ry), (int) Math.floor(fz));
            Block there = world.getBlockState(p).getBlock();
            if (!there.isReplaceable(world, p)) continue;
            BlockPos ground = TreeDetector.nearestGround(world, p);
            IBlockState st = n.state;
            if (st.getBlock() instanceof BlockLog && st.getPropertyKeys().contains(BlockLog.LOG_AXIS)) {
                st = st.withProperty(BlockLog.LOG_AXIS, axis);
            }
            world.setBlockState(ground, st, 11);
        }
        DawnNetwork.shake(world, posX, posY, posZ, 1.2F, 20, 18.0D);
        setDead();
    }

    // ------------------------------------------------------------ creation (Dawn Era createFallingTree)

    /**
     * Topples the tree that the log at logPos belongs to, away from fallFrom. Needs a vertical log at the foot of the
     * tree, 3 or more logs (fewer than limit) and 3 or more leaves.
     */
    public static boolean createFallingTree(World world, BlockPos logPos, Vec3d fallFrom, int limit) {
        BlockPos origin = TreeDetector.bottomOfTree(world, logPos);
        if (!TreeDetector.isNormalRotatedLog(world, origin)) return false;
        Set<BlockPos> logs = new HashSet<>();
        Set<BlockPos> leaves = new HashSet<>();
        TreeDetector.searchForLogs(world, logPos, limit, logs);
        if (logs.size() < 3 || logs.size() >= limit) return false;
        TreeDetector.searchForLeaves(world, logs, leaves);
        if (leaves.size() < 3) return false;

        EntityFallingTree tree = new EntityFallingTree(world);
        Vec3d v = new Vec3d(origin.getX() + 0.5D, origin.getY() + 0.5D, origin.getZ() + 0.5D).subtract(fallFrom);
        float yaw = (float) Math.toDegrees(Math.atan2(v.x, v.z));
        tree.setLocationAndAngles(origin.getX() + 0.5D, origin.getY(), origin.getZ() + 0.5D, yaw, 0.0F);

        Set<BlockPos> gathered = new HashSet<>(logs);
        gathered.addAll(leaves);
        for (BlockPos p : gathered) {
            tree.nodes.add(new Node(p.subtract(origin), world.getBlockState(p)));
        }
        world.spawnEntity(tree);
        SoundEvent snd = DawnSounds.get("misc.tree.fall");
        if (snd != null) world.playSound(null, origin.getX(), origin.getY(), origin.getZ(), snd, SoundCategory.BLOCKS, 1.0F, 0.9F + world.rand.nextFloat() * 0.2F);
        for (BlockPos p : gathered) world.setBlockState(p, Blocks.AIR.getDefaultState(), 2);
        return true;
    }

    // ------------------------------------------------------------ sync + save

    @Override
    public void writeSpawnData(ByteBuf b) {
        b.writeFloat(rotationYaw);
        b.writeInt(fallTicks);
        b.writeInt(nodes.size());
        for (Node n : nodes) {
            b.writeInt(n.offset.getX());
            b.writeInt(n.offset.getY());
            b.writeInt(n.offset.getZ());
            b.writeInt(Block.getStateId(n.state));
        }
    }

    @Override
    public void readSpawnData(ByteBuf b) {
        rotationYaw = b.readFloat();
        prevRotationYaw = rotationYaw;
        fallTicks = b.readInt();
        int c = b.readInt();
        for (int i = 0; i < c; i++) {
            BlockPos off = new BlockPos(b.readInt(), b.readInt(), b.readInt());
            nodes.add(new Node(off, Block.getStateById(b.readInt())));
        }
    }

    @Override
    protected void writeEntityToNBT(NBTTagCompound c) {
        c.setInteger("FallTicks", fallTicks);
        NBTTagList list = new NBTTagList();
        for (Node n : nodes) {
            NBTTagCompound t = new NBTTagCompound();
            t.setInteger("x", n.offset.getX());
            t.setInteger("y", n.offset.getY());
            t.setInteger("z", n.offset.getZ());
            t.setInteger("s", Block.getStateId(n.state));
            list.appendTag(t);
        }
        c.setTag("Nodes", list);
    }

    @Override
    protected void readEntityFromNBT(NBTTagCompound c) {
        fallTicks = c.getInteger("FallTicks");
        NBTTagList list = c.getTagList("Nodes", 10);
        nodes.clear();
        for (int i = 0; i < list.tagCount(); i++) {
            NBTTagCompound t = list.getCompoundTagAt(i);
            nodes.add(new Node(new BlockPos(t.getInteger("x"), t.getInteger("y"), t.getInteger("z")), Block.getStateById(t.getInteger("s"))));
        }
    }
}
