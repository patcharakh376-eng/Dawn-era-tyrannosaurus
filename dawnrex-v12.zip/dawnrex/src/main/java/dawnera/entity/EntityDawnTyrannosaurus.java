package dawnera.entity;

import dawnera.DawnBlocks;
import dawnera.DawnNetwork;
import dawnera.TreeDetector;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Deque;
import java.util.HashSet;
import java.util.Set;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLeaves;
import net.minecraft.block.BlockLog;
import net.minecraft.block.material.Material;
import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.*;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Items;
import net.minecraft.init.MobEffects;
import net.minecraft.init.SoundEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.DamageSource;
import net.minecraft.util.EnumParticleTypes;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/** Tyrannosaurus (Dawn Era values: tyrannosaurus.json). */
public class EntityDawnTyrannosaurus extends EntityDawnCreature {
    public static final Action ATTACK1 = new Action("attack1", "animation.model.attack1", 15);
    public static final Action ATTACK2 = new Action("attack2", "animation.model.attack2", 19);
    public static final Action RAM = new Action("ram", "animation.model.attack3", 20);
    public static final Action GROUND = new Action("ground", "animation.model.attack4", 24);
    public static final Action ROAR = new Action("roar", "animation.model.roar", 81);
    public static final Action SNIFF = new Action("sniff", "animation.model.sniff", 39);
    public static final Action EAT = new Action("eat", "animation.model.eat", 66);
    private static final Action[] ACTIONS = {ATTACK1, ATTACK2, RAM, GROUND, ROAR, SNIFF, EAT};

    public EntityDawnTyrannosaurus(World world) {
        super(world);
        setSize(4.0F, 4.5F);
        experienceValue = 40;
        initDefaults();
    }

    @Override public String getSpeciesId() { return "tyrannosaurus"; }
    @Override protected Action[] getActions() { return ACTIONS; }
    @Override protected float getBaseWidth() { return 4.0F; }
    @Override protected float getBaseHeight() { return 4.5F; }
    @Override protected int getAdultAgeTicks() { return 24000 * 5; }
    @Override protected float getMaxHunger() { return 150.0F; }
    /** Female 370 HP, male 380 HP (+10 armor, see getMaleArmorBonus). */
    @Override protected float getAdultMaxHealth() { return isMale() ? 380.0F : 370.0F; }
    @Override protected double getMaleArmorBonus() { return 10.0D; }
    @Override protected Action getEatAction() { return EAT; }
    @Override public int getMaxSpawnedInChunk() { return 1; }

    @Override
    protected void applyEntityAttributes() {
        super.applyEntityAttributes();
        getAttributeMap().registerAttribute(SharedMonsterAttributes.ATTACK_DAMAGE);
        getEntityAttribute(SharedMonsterAttributes.MAX_HEALTH).setBaseValue(370.0D);
        getEntityAttribute(SharedMonsterAttributes.MOVEMENT_SPEED).setBaseValue(0.25D);
        getEntityAttribute(SharedMonsterAttributes.KNOCKBACK_RESISTANCE).setBaseValue(1.0D);
        getEntityAttribute(SharedMonsterAttributes.FOLLOW_RANGE).setBaseValue(64.0D);
        getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).setBaseValue(60.0D);
        getEntityAttribute(SharedMonsterAttributes.ARMOR).setBaseValue(35.0D);
    }

    @Override
    protected void initEntityAI() {
        this.aiSit = new EntityAISit(this);
        tasks.addTask(1, aiSit);
        tasks.addTask(2, new DawnAIMelee(this, 1.7D));
        tasks.addTask(3, new DawnAIMate(this));
        tasks.addTask(4, new EntityAIFollowOwner(this, 1.6D, 10.0F, 3.0F) {
            @Override public boolean shouldExecute() { return isFollowing() && super.shouldExecute(); }
            @Override public boolean shouldContinueExecuting() { return isFollowing() && super.shouldContinueExecuting(); }
        });
        tasks.addTask(5, new EntityAIWander(this, 0.8D));
        tasks.addTask(6, new EntityAIWatchClosest(this, EntityPlayer.class, 10.0F));
        tasks.addTask(7, new EntityAILookIdle(this));
        targetTasks.addTask(0, new EntityAIOwnerHurtByTarget(this));
        targetTasks.addTask(1, new EntityAIOwnerHurtTarget(this));
        targetTasks.addTask(2, new EntityAIHurtByTarget(this, false));
        // wild and hungry: hunt animals
        targetTasks.addTask(3, new EntityAINearestAttackableTarget<EntityAnimal>(this, EntityAnimal.class, 10, true, false,
                a -> isHungry() && !isTamed() && isAdult() && !(a instanceof EntityDawnCreature)));
    }

    // ------------------------------------------------------------ spawning (rare, never crowded)

    @Override
    public boolean getCanSpawnHere() {
        if (rand.nextInt(3) != 0) return false;
        if (!world.getEntitiesWithinAABB(EntityDawnTyrannosaurus.class, getEntityBoundingBox().grow(128.0D, 64.0D, 128.0D)).isEmpty()) return false;
        BlockPos pos = new BlockPos(posX, getEntityBoundingBox().minY, posZ);
        Material m = world.getBlockState(pos.down()).getMaterial();
        return (m == Material.GRASS || m == Material.GROUND) && world.getLight(pos) > 8 && isNotColliding();
    }

    // ------------------------------------------------------------ behaviour

    @Override
    public Action pickAttack() {
        int r = rand.nextInt(100);
        if (!isAdult()) return ATTACK1;
        if (r < 30) return ATTACK1;
        if (r < 60) return ATTACK2;
        if (r < 80) return RAM;
        return onGround ? GROUND : ATTACK1;
    }

    @Override
    public void onLivingUpdate() {
        super.onLivingUpdate();
        if (world.isRemote) return;
        if (!isLocked() && !isResting() && !isBeingRidden() && getAttackTarget() == null && !isInWater() && !isSitting()) {
            if (rand.nextInt(1500) == 0) startAction(ROAR);
            else if (isHungry() && rand.nextInt(700) == 0) startAction(SNIFF);
        }
        if (isAdult() && !isResting()) breakLeavesDropTrees();
    }

    /**
     * Dawn Era breakLeavesDropTrees. A log within 3 blocks of the body topples the whole tree (costs 5 stamina, slows
     * it for a second); leaves inside the body + 1 block are smashed (the first 6 per tick with effects).
     * Wild ones obey the mobGriefing rule; a ridden one is under the player's control, so it always works.
     */
    private void breakLeavesDropTrees() {
        boolean ridden = getRiderPlayer() != null;
        if (!ridden && !world.getGameRules().getBoolean("mobGriefing")) return;

        boolean felled = false;
        if (getEnergy() > 5.0F) {
            AxisAlignedBB tb = getEntityBoundingBox().grow(3.0D, 0.0D, 3.0D);
            for (BlockPos p : BlockPos.getAllInBox(new BlockPos(tb.minX, tb.minY, tb.minZ), new BlockPos(tb.maxX, tb.maxY, tb.maxZ))) {
                if (!TreeDetector.isLog(world.getBlockState(p))) continue;
                if (EntityFallingTree.createFallingTree(world, p.toImmutable(), getPositionVector(), 64)) {
                    consumeEnergy(5.0F);
                    addPotionEffect(new PotionEffect(MobEffects.SLOWNESS, 20, 1, false, false));
                    felled = true;
                    break;
                }
            }
        }
        if (!felled && ridden) {
            // stumps, tiny trees and anything that cannot topple are simply smashed when a player drives into them
            AxisAlignedBB sb = getEntityBoundingBox().grow(1.0D, 0.0D, 1.0D);
            for (BlockPos p : BlockPos.getAllInBox(new BlockPos(sb.minX, sb.minY, sb.minZ), new BlockPos(sb.maxX, sb.maxY, sb.maxZ))) {
                if (TreeDetector.isLog(world.getBlockState(p))) world.destroyBlock(p.toImmutable(), true);
            }
        }

        AxisAlignedBB lb = getEntityBoundingBox().grow(1.0D);
        int fx = 0;
        for (BlockPos p : BlockPos.getAllInBox(new BlockPos(lb.minX, lb.minY, lb.minZ), new BlockPos(lb.maxX, lb.maxY, lb.maxZ))) {
            if (!(world.getBlockState(p).getBlock() instanceof BlockLeaves)) continue;
            if (fx < 6) { world.destroyBlock(p.toImmutable(), false); fx++; }
            else world.setBlockToAir(p.toImmutable());
        }
    }

    @Override
    protected void layEgg() {
        BlockPos base = new BlockPos(posX, posY, posZ);
        for (BlockPos p : BlockPos.getAllInBox(base.add(-2, -1, -2), base.add(2, 1, 2))) {
            if (world.isAirBlock(p) && world.isSideSolid(p.down(), net.minecraft.util.EnumFacing.UP)) {
                world.setBlockState(p, DawnBlocks.EGG.getDefaultState());
                playSound(SoundEvents.ENTITY_CHICKEN_EGG, 1.0F, 0.6F);
                return;
            }
        }
        entityDropItem(new ItemStack(Item.getItemFromBlock(DawnBlocks.EGG)), 0.5F);
    }

    // ------------------------------------------------------------ rider input (Dawn Era InputControls)

    /** attack = random bite/ram (10 stamina), roar (20), attack_ground = space (50). */
    @Override
    protected void onRiderInput(String id) {
        if (id.equals("attack") && consumeEnergy(10.0F)) {
            int r = rand.nextInt(130);
            startAction(r < 50 ? ATTACK1 : (r < 100 ? ATTACK2 : RAM));
        } else if (id.equals("roar") && consumeEnergy(20.0F)) {
            startAction(ROAR);
        } else if (id.equals("attack_ground") && consumeEnergy(50.0F)) {
            startAction(GROUND);
        }
    }

    // ------------------------------------------------------------ actions and effects

    @Override
    protected void onActionTick(Action a, int t) {
        if (a == ATTACK1 || a == ATTACK2) {
            if (t == 1) playSound(sound("attack"), 1.0F, getSoundPitch());
            if ((a == ATTACK1 && t == 10) || (a == ATTACK2 && t == 12)) bite(1.25F, 1.55F);
        } else if (a == RAM) {
            if (t == 1) playSound(sound("ram"), 1.0F, getSoundPitch());
            if (t == 7) {
                bite(1.15F, 2.0F);
                for (EntityLivingBase e : frontEntities(3.5D)) if (e != getAttackTarget()) damage(e, 0.7F);
                Vec3d f = forward();
                particles(EnumParticleTypes.EXPLOSION_NORMAL, posX + f.x * width * 0.6D, posY + 0.5D, posZ + f.z * width * 0.6D, 12, 0.8D, 0.3D, 0.8D, 0.05D);
            }
        } else if (a == GROUND) {
            if (t == 5) playSound(sound("attack_ground"), 1.6F, getSoundPitch());
            if (t == 12) groundSlam();
        } else if (a == ROAR) {
            if (t == 15) roar();
        } else if (a == SNIFF) {
            if (t == 10) playSound(sound("sniff"), 1.0F, getSoundPitch() * 0.65F);
        } else if (a == EAT) {
            if (t >= 10 && t <= 60 && t % 6 == 0) {
                Vec3d h = headPos();
                particles(EnumParticleTypes.ITEM_CRACK, h.x, h.y - 0.6D, h.z, 6, 0.3D, 0.2D, 0.3D, 0.05D, Item.getIdFromItem(Items.BEEF), 0);
            }
        }
    }

    /** Roar: shock cloud from the mouth, camera shake, nearby creatures are pushed back and weakened. */
    private void roar() {
        playSound(sound("roar"), 3.0F, getSoundPitch());
        Vec3d h = headPos();
        Vec3d f = forward();
        for (int i = 0; i < 30; i++) {
            double sp = 0.35D + rand.nextDouble() * 0.5D;
            particles(EnumParticleTypes.CLOUD, h.x, h.y, h.z, 0,
                    f.x * sp + rand.nextGaussian() * 0.12D, rand.nextGaussian() * 0.08D, f.z * sp + rand.nextGaussian() * 0.12D, 1.0D);
        }
        for (int i = 0; i < 24; i++) {
            double ang = i * Math.PI / 12.0D;
            particles(EnumParticleTypes.SMOKE_NORMAL, posX, posY + 0.3D, posZ, 0, Math.cos(ang) * 0.5D, 0.02D, Math.sin(ang) * 0.5D, 1.0D);
        }
        wakeUpOthers(20.0D);
        DawnNetwork.shake(world, posX, posY, posZ, 0.8F, 50, 40.0D);
        EntityPlayer rider = getRiderPlayer();
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(12.0D, 4.0D, 12.0D))) {
            if (isFriendly(e, rider)) continue;
            double dx = e.posX - posX, dz = e.posZ - posZ;
            double len = Math.max(0.5D, Math.sqrt(dx * dx + dz * dz));
            e.motionX += dx / len * 0.5D;
            e.motionZ += dz / len * 0.5D;
            e.motionY += 0.15D;
            e.velocityChanged = true;
            e.addPotionEffect(new PotionEffect(MobEffects.WEAKNESS, 100, 0, true, false));
        }
    }

    /** Bite: the AI target, or everything in front when a player rides. */
    private void bite(float playerMult, float otherMult) {
        EntityPlayer rider = getRiderPlayer();
        if (rider == null) {
            EntityLivingBase t = getAttackTarget();
            if (t != null && getDistance(t) - (width + t.width) * 0.5F <= 2.6F) hit(t, playerMult, otherMult);
        } else {
            for (EntityLivingBase t : frontEntities(4.5D)) hit(t, playerMult, otherMult);
        }
    }

    private void hit(EntityLivingBase t, float playerMult, float otherMult) {
        damage(t, t instanceof EntityPlayer ? playerMult : otherMult);
        if (isAdult()) slow(t, 180, 1);
        Vec3d look = getLookVec();
        t.motionX += look.x * 0.5D;
        t.motionZ += look.z * 0.5D;
        t.motionY += 0.25D;
        t.velocityChanged = true;
    }

    /** Ground slam: shockwave rings of dust, camera shake, damage + slow + launch. */
    private void groundSlam() {
        EntityPlayer rider = getRiderPlayer();
        for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(3.5D, 2.0D, 3.5D))) {
            if (isFriendly(e, rider)) continue;
            e.attackEntityFrom(DamageSource.causeMobDamage(this), 30.0F * DAMAGE_SCALE);
            slow(e, 100, 2);
            e.motionY += 0.5D;
            e.velocityChanged = true;
        }
        BlockPos below = new BlockPos(posX, posY - 0.5D, posZ);
        for (int ring = 1; ring <= 5; ring++) {
            double r = ring * 1.2D + 0.5D;
            for (int i = 0; i < 18 + ring * 2; i++) {
                double ang = i * Math.PI * 2.0D / (18 + ring * 2) + ring * 0.3D;
                double x = posX + Math.cos(ang) * r, z = posZ + Math.sin(ang) * r;
                IBlockState st = world.getBlockState(new BlockPos(x, posY - 0.5D, z));
                if (st.getMaterial() == Material.AIR) st = world.getBlockState(below);
                if (st.getMaterial() == Material.AIR) continue;
                particles(EnumParticleTypes.BLOCK_DUST, x, posY + 0.1D, z, 4, 0.25D, 0.15D, 0.25D, 0.15D, Block.getStateId(st));
            }
        }
        particles(EnumParticleTypes.EXPLOSION_LARGE, posX, posY + 0.3D, posZ, 2, 1.5D, 0.1D, 1.5D, 0.0D);
        DawnNetwork.shake(world, posX, posY, posZ, 2.5F, 16, 32.0D);
    }

    @Override
    protected void playStepSound(BlockPos pos, Block block) {
        if (isChild() || isInWater()) return;
        playSound(sound("step"), 1.0F, getSoundPitch());
        if (!world.isRemote) {
            DawnNetwork.shake(world, posX, posY, posZ, 0.1F, 6, 22.0D);
            for (EntityLivingBase e : world.getEntitiesWithinAABB(EntityLivingBase.class, getEntityBoundingBox().grow(0.5D).expand(0, -0.5D, 0))) {
                if (isFriendly(e, getRiderPlayer()) || e.height / height >= 0.5F) continue;
                e.attackEntityFrom(DamageSource.causeMobDamage(this), (float) getEntityAttribute(SharedMonsterAttributes.ATTACK_DAMAGE).getAttributeValue() * 0.45F);
            }
        }
    }
}
