package dawnera.client;

import dawnera.entity.EntityFallingTree;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.EnumBlockRenderType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

/** Draws all blocks of the falling tree in one batch, rotated about the foot of the trunk (Dawn Era TDEFallingTreeRenderer). */
@SideOnly(Side.CLIENT)
public class RenderFallingTree extends Render<EntityFallingTree> {
    public RenderFallingTree(RenderManager rm) {
        super(rm);
        this.shadowSize = 0.0F;
    }

    @Override
    public void doRender(EntityFallingTree e, double x, double y, double z, float yaw, float partial) {
        if (e.getNodes().isEmpty()) return;
        bindTexture(TextureMap.LOCATION_BLOCKS_TEXTURE);
        GlStateManager.pushMatrix();
        GlStateManager.disableLighting();
        GlStateManager.translate((float) x, (float) y, (float) z);
        GlStateManager.rotate(e.prevRotationYaw + (e.rotationYaw - e.prevRotationYaw) * partial, 0.0F, 1.0F, 0.0F);
        GlStateManager.rotate(e.getAngle(partial), 1.0F, 0.0F, 0.0F);

        BlockPos ref = new BlockPos(e.posX, e.posY, e.posZ);
        BlockRendererDispatcher d = Minecraft.getMinecraft().getBlockRendererDispatcher();
        Tessellator t = Tessellator.getInstance();
        BufferBuilder bb = t.getBuffer();
        bb.begin(7, DefaultVertexFormats.BLOCK);
        for (EntityFallingTree.Node n : e.getNodes()) {
            IBlockState s = n.state;
            if (s.getRenderType() != EnumBlockRenderType.MODEL) continue;
            bb.setTranslation(-ref.getX() + n.offset.getX() - 0.5D, -ref.getY() + n.offset.getY(), -ref.getZ() + n.offset.getZ() - 0.5D);
            d.getBlockModelRenderer().renderModel(e.world, d.getModelForState(s), s, ref, bb, false, MathHelper.getPositionRandom(ref));
        }
        bb.setTranslation(0.0D, 0.0D, 0.0D);
        t.draw();
        GlStateManager.enableLighting();
        GlStateManager.popMatrix();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityFallingTree e) { return TextureMap.LOCATION_BLOCKS_TEXTURE; }
}
